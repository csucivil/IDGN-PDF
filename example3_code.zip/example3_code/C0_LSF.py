

def Z(x):  # 定义功能函数,输入X为向量（numvar,）

    import numpy as np

    z1=  3*x[:, 3]-np.abs(  2* x[:, 4]/(x[:, 0]*np.power(np.power( (x[:, 1]+x[:, 2])/x[:, 0] ,0.5),2))*np.sin( np.power( (x[:, 1]+x[:, 2])/x[:, 0] ,0.5)*x[:, 5]/2 ) )

    z = z1.reshape(-1, )*1.0

    return z





#
def fun_z(x):  # 定义功能函数,输入X为向量（numvar,）
    #
    # print('x',x[:,0])
    # print('x', x[:, 1])
    import numpy as np

    z0= x[:,0]-1e-10

    z = z0.reshape(-1, )*1.0
    # print('z',z)
    return z

