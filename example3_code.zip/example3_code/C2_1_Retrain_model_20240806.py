
# def DGN_Sampling(seq,res):


'''
seq = 2  # 连续抽样轮编号
res = 201 # 实验编号
'''

seq = 2      # 连续抽样轮编号
res =11   # 实验编号

import torch
from torch import nn, optim, distributions
from torch.nn import functional as F
from torch.autograd import Variable
from torchvision import transforms
from torchvision.utils import save_image

from sklearn import datasets
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from pylab import rcParams
import os
import random
from scipy import io
#



sequence = seq  # 连续抽样轮编号
result = res  # 实验编号

# =================================  定义文件路径创建函数    =========================================
LOG_DIR = 'F:/XZL_Research/python_work/FLOW_PDF/example3/results' + str(result)

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


# 函数
def mkdir(path):
    import os
    path = path.strip()  # 去除首位空格
    path = path.rstrip("\\")  # 去除尾部 \ 符号
    isExists = os.path.exists(path)  # 判断路径是否存在

    # 判断结果
    if not isExists:
        os.makedirs(path)  # 如果不存在则创建目录


# # 调用函数
path = LOG_DIR  # 创建文件夹
mkdir(path)
path = LOG_DIR + '/Seq' + str(sequence)  # 创建文件夹
mkdir(path)
# ===================================================================================



# ===============================  0 参数   =============================
for i in range(1):

    #导入模型的epoch
    model_load_epoch =1300

    # ====== 1== 整个网络（响应预测模型）
    # --- data loading --- #
    # 导入样本X
    filename_MCS = LOG_DIR + '/Seq1/sampledata1.npz'
    dataMCS = np.load(filename_MCS)
    numvar = int(dataMCS['numvar'])

    # --- configuration --- #
    EPOCHS_MAX = 1000    # 交叉验证最大epoch数
    BATCH_SIZE = 100  # batchsize要大于交叉验证的num_fold，否则当dataset2无标签数据为空时，交叉验证会引入一些全为0的数据集
    MAX_NORM = 1e20  # 梯度范数裁剪
    STEP_LOSS_PRINT = 100  # print loss的间隔step数( =样本数N/批样本数/每个epoch打印次数 )
    EPOCH_DENSITY_PLOT = 20  # 画图-预测概率密度+真实概率密度--的间隔epoch数
    EPOCH_MODEL_SAVE = 100  # 保存模型的epoch频率

    weight_loss1 = 1.0  # loss1的权重系数   生成网络概率密度
    weight_loss2 = 0.5  # loss2的权重系数   输出单调性
    weight_loss3 = 0.0  # loss3的权重系数   预测概率密度形状约束
    weight_loss4 = 0.0  # loss4的权重系数   MNET单调网络输出的离散性约束
    weight_loss4_ = 0.0  # loss4的权重系数(最后一epoch)
    lr_weights = 1e-4  # weights初始学习率

    logpt_input_low = -1e30  # logp的输入裁剪下界，只在绘图中设置，不影响训练结果，对数正态分布大于零，正态分布为负无穷
    logpt_input_up = 1e30  # logp的输入裁剪下界，只在绘图中设置，不影响训练结果，

    # ====== 1== G1网络（随机变量概率分布拟合）
    INPUT_DIM = numvar  # couplelayer  输入单元数
    OUTPUT_DIM = numvar  # couplelayer  输出单元数
    HIDDEN_DIM = 256 * 1  # couplelayer  隐层单元数
    NUM_LAYERS_S = 5  # couplelayer  S网络层数
    NUM_LAYERS_T = 5  # couplelayer  T网络层数
    N_COUPLE_LAYERS = 20  # couplelayer  嵌套个数
    # SAVE_PLT_INTERVAL = 5

    lr_initial0 = 5e-5  # 初始学习率
    # lr_step_size = 500  # 学习率折减step数，不是epoch
    # lr_gamma = 1.0  # 学习率折减系数

    loss1_low = -11.0   #clamp loss1,   裁剪loss1范围，避免特别小地负数，导致loss2不起作用，根据训练样本中最大样本概率密度计算loss1下限，-log（pdf）,35000--10.46
    loss1_up = 100    #

    # ====== 4== SMNET 网络（响应预测模型）
    INPUT_SIZE = 1  # MNET网络输入层节点数（输出层默认1）
    GROUP_NUM = 300  # MNET网络分组数量
    GROUP_SIZE = 300  # MNET网络每组节点数
    lr_mnet_initial0 = 1e-3  # MNET网络初始学习率

    # N_STEP_MNET = 1    # 在每个step中G2网络额外训练的步数
    N_STEP_MNET_ = 100  # 在每个step中G2网络额外训练的步数(最后一epoch)

    # ====== 3== G2网络（响应预测模型）
    HIDDEN_DIM_G2 = 256 * 1  # couplelayer  隐层单元数
    NUM_LAYERS_S_G2 = 5  # couplelayer  S网络层数
    NUM_LAYERS_T_G2 = 5  # couplelayer  T网络层数
    N_COUPLE_LAYERS_G2 = 10  # couplelayer  嵌套个数

    loss_low = -10000  # loss裁剪下界，避免出现NAN
    loss_up = 10000  # loss裁剪上界，避免出现NAN
    lr_G2_initial0 = 1e-4  # G2网络初始学习率
    # N_STEP_G2 = 1    # 在每个step中G2网络额外训练的步数
    N_STEP_G2_ = 100  # 在每个step中G2网络额外训练的步数(最后一epoch)

    torch.set_default_dtype(torch.float64)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')  # 判断是否有GPU，定义计算设备，  后面视乎没有调用GPU的命令？

# ===============================  1 导入MCS数据-data1-label   =============================

# ====================  1-1 data1-label 带标签  ===================
for i in range(1):

    # --- data loading --- #
    # 导入样本X
    filename_MCS = LOG_DIR + '/Seq1/sampledata1.npz'
    dataMCS = np.load(filename_MCS)

    N1 = dataMCS['N']
    N = N1
    numvar = int(dataMCS['numvar'])
    XO = dataMCS['XO']
    X2 = dataMCS['X2']
    Y = dataMCS['Y']
    # Pf_MCS = dataMCS['Pf_MCS']   #用于计算条件概率密度
    Pf_MCS = 1.0  # 用于计算条件概率密度

    XDEN = dataMCS['XDEN']
    XDEN_Joint = np.ones((N, 1))  # 计算联合概率密度
    for i in range(0, numvar):
        XDEN_Joint[:, 0] = XDEN_Joint[:, 0] * XDEN[:, i]

    XDEN_Joint = XDEN_Joint / Pf_MCS  # 条件概率密度
    # XDEN_Joint=XDEN[:,0]*XDEN[:,1]

    dataset = np.zeros((N, numvar + 2))    # XO + Y + X2
    dataset[:, 0:numvar] = XO[:, 0:numvar]
    dataset[:, numvar] = Y[:, 0]
    dataset[:, numvar+1] = X2[:, 0]
    dataset1 = dataset.astype(np.float64)

    # 计算归一化参数初始值
    m_init = np.mean(dataset1[:, numvar])  # 极限状态函数均值
    std_init = 1.0*np.std(dataset1[:, numvar])  # 极限状态函数标准差

    # 训练数据概率密度
    # import matplotlib.pyplot as plt
    # from mpl_toolkits.mplot3d import Axes3D
    plt.clf()
    plt.close('all')
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    ax.scatter(dataset1[:, 0], dataset1[:, 1], XDEN_Joint)
    plt.title('training data_density')
    plt.xlim(-10, 10)  # 设置X轴显示范围
    plt.ylim(-10, 10)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.xlabel('X0', fontproperties='Arial', fontsize=14)
    plt.ylabel('X1', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/traning_data_density.png')

    '''
    p_data = distributions.MultivariateNormal(torch.zeros(numvar), torch.eye(numvar)*4)   # torch.eye(int(numvar)) 为协方差，而不是标准差
    # xt=torch.from_numpy(np.array([0,0]))
    # logpt=p_data.log_prob(xt)
    # pt=torch.exp(logpt)
    '''

    '''
    train_data =datasets.make_moons(n_samples=50000, noise=.05)[0].astype(np.float64)
    test_data = datasets.make_moons(n_samples=1000, noise=.05)[0].astype(np.float64)
    '''

    '''
    # 直方图检查数据
    d=0
    plt.figure(figsize=[6, 6])
    plt.hist(train_data[:, d], 100, density=True)  # 直方图
    plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    plt.xlabel(u'd)', fontproperties='Arial', fontsize=14)
    plt.ylabel(u'Probability density', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence)+ '/训练数据直方图d='+str(d)+'.png')

    '''

    # 绘制二维离散点
    # =====================
    plt.clf()
    plt.close('all')
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.figure(figsize=[10, 10])
    plt.scatter(dataset1[:, 0], dataset1[:, 1], s=5, c='r', marker='.')  # 总体中剩余样本中  失效的样本
    # plt.legend(["Failure", "Save"], loc=2, ncol=2)  # 设置图例
    plt.xlim(-10, 10)  # 设置X轴显示范围
    plt.ylim(-10, 10)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('X0', fontproperties='Arial', fontsize=14)
    plt.ylabel('X1', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/train_data_from_0and1_dimension.png')

    # ===检查训练样本的极限状态函数分布范围
    train_data_torch = torch.from_numpy(dataset1)
    aa = torch.argsort(train_data_torch[:, numvar], dim=0)
    train_data_g_sort = train_data_torch[aa, :]
    train_data_g_sort_np = train_data_g_sort.numpy()
    train_data_g_sort_np_n = np.reshape((train_data_g_sort_np[:, numvar] - m_init) / (std_init + 1e-20), (-1, 1))

    # 实际未归一化
    plt.clf()
    plt.close('all')
    fig = plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('train_data_g_sort_np')
    plt.plot(np.arange(np.shape(train_data_g_sort_np)[0]), train_data_g_sort_np[:, numvar], c='b')
    plt.legend(["train_data_g_sort_np"], loc=2, ncol=2)  # 设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('N', fontproperties='Arial', fontsize=14)
    plt.ylabel('train_data_g_sort_np', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/train_data_g_sort_np.png')

    # 归一化
    plt.clf()
    plt.close('all')
    fig = plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('train_data_g_sort_np_n')
    plt.plot(np.arange(np.shape(train_data_g_sort_np_n)[0]), train_data_g_sort_np_n[:, 0], c='b')
    plt.legend(["train_data_g_sort_np_n"], loc=2, ncol=2)  # 设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('N', fontproperties='Arial', fontsize=14)
    plt.ylabel('train_data_g_sort_np_n', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/train_data_g_sort_np_n.png')

    # pin memory provides improved transfer speed
    # kwargs = {'num_workers': 1, 'pin_memory': True} if device == 'cuda' else {}
    # train_loader = torch.utils.data.DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True,**kwargs)  # 训练测试数据加载器，自动将数据分成batch
    # test_loader = torch.utils.data.DataLoader(test_data, batch_size=BATCH_SIZE, shuffle=True, **kwargs)
    #
    # train_loader2 = torch.utils.data.DataLoader(train_data2, batch_size=BATCH_SIZE, shuffle=True,**kwargs)  # 训练测试数据加载器，自动将数据分成batch
    # test_loader2 = torch.utils.data.DataLoader(test_data2, batch_size=BATCH_SIZE, shuffle=True, **kwargs)

# ====================  1-2 data2-unlabel  不带标签  ===================
for i in range(1):
    # --- data loading --- #
    # 导入样本X
    filename_MCS = LOG_DIR + '/Seq1/sampledata2.npz'
    dataMCS = np.load(filename_MCS)

    N2 = dataMCS['N']
    N = N2
    numvar = int(dataMCS['numvar'])
    XO = dataMCS['XO']
    X2 = dataMCS['X2']
    Y = dataMCS['Y']  # 在无标签样本中不起作用
    # Pf_MCS = dataMCS['Pf_MCS']   #用于计算条件概率密度
    Pf_MCS = 1.0  # 用于计算条件概率密度

    XDEN = dataMCS['XDEN']
    XDEN_Joint = np.ones((N, 1))  # 计算联合概率密度
    for i in range(0, numvar):
        XDEN_Joint[:, 0] = XDEN_Joint[:, 0] * XDEN[:, i]

    XDEN_Joint = XDEN_Joint / Pf_MCS  # 条件概率密度
    # XDEN_Joint=XDEN[:,0]*XDEN[:,1]

    dataset = np.zeros((N, numvar + 2))    # XO + Y + X2
    dataset[:, 0:numvar] = XO[:, 0:numvar]
    dataset[:, numvar] = Y[:, 0]
    dataset[:, numvar+1] = X2[:, 0]
    dataset2 = dataset.astype(np.float64)
    dataset2[:, numvar] = 0  # 极限状态函数为空

    # 计算归一化参数初始值
    # m_init = np.mean(dataset2[:, numvar])  # 极限状态函数均值
    # std_init = np.std(dataset2[:, numvar])  # 极限状态函数标准差




# ===============================  2 搭建生成网络   =============================



# ===搭建G1模型-CouplingLayer网络（不限制单调递增）===
class CouplingLayer(nn.Module):
    def __init__(self, input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, mask):
        super().__init__()

        # ======  s_fcs网络  （相乘的系数beta）
        self.num_layers_s = num_layers_s
        self.s_fc1 = nn.Sequential(nn.Linear(input_dim, hid_dim), nn.ReLU())
        dense_s = []
        for i in range(1, self.num_layers_s - 1):
            dense_s.append(nn.Sequential(nn.Linear(hid_dim, hid_dim), nn.ReLU()))
        self.dense_block_s = torch.nn.ModuleList(dense_s)
        # self.s_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim), nn.Tanh())  #Tanh激活，也可以线性激活
        self.s_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim))  # Tanh激活，也可以线性激活

        #  s_fcs网络参数初始化，bias小一点，避免突然映射得到偏离正太分布很远的分布
        MU_WEI_INIT_G1_s_fcs = 0
        STD_WEI_INIT_G1_s_fcs=1e-3
        for name, param in self.s_fc1.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G1_s_fcs, STD_WEI_INIT_G1_s_fcs)
                # print(1)
            if 'bias' in name:
                # print(2)
                nn.init.constant_(param, val=0.0)

        for name, param in self.dense_block_s.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G1_s_fcs, STD_WEI_INIT_G1_s_fcs)
            if 'bias' in name:
                # print(1)
                nn.init.constant_(param, val=0.0)
        for name, param in self.s_fc3.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G1_s_fcs, STD_WEI_INIT_G1_s_fcs)
            if 'bias' in name:
                # print(1)
                nn.init.constant_(param, val=0.8)     # G1  输出层初始值为1，映射系数为1，使得网络将高斯分布映射为原始高斯分布；该参数初始化为0容易导致log出现nan；任何数据分布都可以先预处理，rescale到N（0，1）附近。



        # ======  t_fcs网络  （相加的偏置项gama）
        self.num_layers_t = num_layers_t
        self.t_fc1 = nn.Sequential(nn.Linear(input_dim, hid_dim), nn.ReLU())
        dense_t = []
        for i in range(1, self.num_layers_t - 1):
            dense_t.append(nn.Sequential(nn.Linear(hid_dim, hid_dim), nn.ReLU()))
        self.dense_block_t = torch.nn.ModuleList(dense_t)
        self.t_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim))  # 线性激活
        # print( 'self.dense_block', self.dense_block  )

        #  t_fcs网络参数初始化
        MU_WEI_INIT_G1_t_fcs = 0
        STD_WEI_INIT_G1_t_fcs=1e-3
        for name, param in self.t_fc1.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G1_t_fcs, STD_WEI_INIT_G1_t_fcs)
            if 'bias' in name:
                # print(3)
                nn.init.constant_(param, val=0.0)
        for name, param in self.dense_block_t.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G1_t_fcs, STD_WEI_INIT_G1_t_fcs)
            if 'bias' in name:
                # print(1)
                nn.init.constant_(param, val=0.0)

        for name, param in self.t_fc3.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G1_t_fcs, STD_WEI_INIT_G1_t_fcs)
            if 'bias' in name:
                # print(1)
                nn.init.constant_(param, val=0.0)   #输出层初始值为0，映射加0，使得网络将高斯分布映射为原始高斯分布

        # ======  mask
        self.mask = mask  # mask  实现交替couplinglayer

    def forward(self, x):  # 求逆+计算雅可比矩阵行列式，由数据样本 到 高斯输入
        x_m = x * self.mask

        # ==s_fcs网络
        s_out = self.s_fc1(x_m)
        for module_s in self.dense_block_s:
            s_out = module_s(s_out)
        s_out = self.s_fc3(s_out)     #             相当于log(beta)，，torch.exp(s_out)相当于beta

        # ==t_fcs网络
        t_out = self.t_fc1(x_m)
        for module_t in self.dense_block_t:
            t_out = module_t(t_out)
        t_out = self.t_fc3(t_out)

        # y = x_m + (1 - self.mask) * (x * torch.exp(s_out) + t_out)  # x1-->xd 和 xd+1-->xD，s_out的激活函数相当于是exp(*),因此直接累加s_out.sum(dim=1)计算log_det_jacobian；但是exp限制了s_out网络只能输出正的，缩小了网络的表达能力；在G2网络中可以采用该激活函数。
        # log_det_jacobian = (s_out * (1 - self.mask)).sum(dim=1)  # s_out相对于exp(s_out)已经计算了log,,  是否应该只计算一半s_out的累加？
        y = x_m + (1 - self.mask) * (x * s_out + t_out)  # s_fcs网络（相乘的系数beta）改为线性激活，提高网络预测能力
        # log_det_jacobian =  (torch.log( torch.abs (s_out) + 1e-30 )* (1 - self.mask)).sum(dim=1)   #只计算一半s_out的累加,  对mini-batch累加，维数[1,numvar]
        log_det_jacobian =  (torch.log( torch.abs (s_out)  )* (1 - self.mask)).sum(dim=1)   #只计算一半s_out的累加,  对mini-batch累加，维数[1,numvar]

        # y = torch.clamp(y, -100, 100)  #constraint the output
        return y, log_det_jacobian  # y取值范围负无穷到正无穷


    def backward(self, y):  # 采样，由高斯输入 到  数据样本
        y_m = y * self.mask

        # ==s_fcs网络
        s_out = self.s_fc1(y_m)
        for module in self.dense_block_s:
            s_out = module(s_out)
        s_out = self.s_fc3(s_out)  # 相当于log(beta)，，torch.exp(s_out)相当于beta

        # ==t_fcs网络
        t_out = self.t_fc1(y_m)
        for module_t in self.dense_block_t:
            t_out = module_t(t_out)
        t_out = self.t_fc3(t_out)

        # x = y_m + (1 - self.mask) * (y - t_out) * torch.exp(-s_out)  # x = y_m + (1 - self.mask) * (y - t_out) ./torch.exp(s_out)  #等效           #相除、分母要不等于0
        # x = y_m + (1 - self.mask) * (y - t_out) / (torch.log(torch.exp(s_out))+1e-20) #     #相除、分母要不等于0
        x = y_m + (1 - self.mask) * (y - t_out) / (s_out) #     #相除、分母要不等于0

        # print( x.shape) #[5,2]
        # x=torch.clamp(x,-100,100)   #constraint the output

        return x


# ===搭建G2模型-CouplingLayer网络（不限制单调递增）===
class CouplingLayer_G2(nn.Module):
    def __init__(self, input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, mask):
        super().__init__()

        # ======  s_fcs网络  （相乘的系数beta）
        self.num_layers_s = num_layers_s
        self.s_fc1 = nn.Sequential(nn.Linear(input_dim, hid_dim), nn.ReLU())
        dense_s = []
        for i in range(1, self.num_layers_s - 1):
            dense_s.append(nn.Sequential(nn.Linear(hid_dim, hid_dim), nn.ReLU()))
        self.dense_block_s = torch.nn.ModuleList(dense_s)
        # self.s_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim), nn.Tanh())  #Tanh激活，也可以线性激活
        self.s_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim))  # Tanh激活，也可以线性激活

        '''
        #  s_fcs网络参数初始化，bias小一点，避免突然映射得到偏离正太分布很远的分布
        MU_WEI_INIT_G2_s_fcs = 0
        STD_WEI_INIT_G2_s_fcs=1e-3
        for name, param in self.s_fc1.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G2_s_fcs, STD_WEI_INIT_G2_s_fcs)
                # print(1)
            if 'bias' in name:
                # print(2)
                nn.init.constant_(param, val=0.0)

        for name, param in self.dense_block_s.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G2_s_fcs, STD_WEI_INIT_G2_s_fcs)
            if 'bias' in name:
                # print(1)
                nn.init.constant_(param, val=0.0)
        for name, param in self.s_fc3.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G2_s_fcs, STD_WEI_INIT_G2_s_fcs)
            if 'bias' in name:
                # print(1)
                nn.init.constant_(param, val=  1e2  )    # G2输出层初始值为0，计算exp激活函数后，映射系数为1，使得网络将高斯分布映射为原始高斯分布；(初始化是递增函数)

        '''

        # ======  t_fcs网络  （相加的偏置项gama）
        self.num_layers_t = num_layers_t
        self.t_fc1 = nn.Sequential(nn.Linear(input_dim, hid_dim), nn.ReLU())
        dense_t = []
        for i in range(1, self.num_layers_t - 1):
            dense_t.append(nn.Sequential(nn.Linear(hid_dim, hid_dim), nn.ReLU()))
        self.dense_block_t = torch.nn.ModuleList(dense_t)
        self.t_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim))  # 线性激活
        # print( 'self.dense_block', self.dense_block  )

        '''
        #  t_fcs网络参数初始化
        MU_WEI_INIT_G2_t_fcs = 0
        STD_WEI_INIT_G2_t_fcs=1e-3

        for name, param in self.t_fc1.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G2_t_fcs, STD_WEI_INIT_G2_t_fcs)
            if 'bias' in name:
                # print(3)
                nn.init.constant_(param, val=0.0)
        for name, param in self.dense_block_t.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G2_t_fcs, STD_WEI_INIT_G2_t_fcs)
            if 'bias' in name:
                # print(1)
                nn.init.constant_(param, val=0.0)

        for name, param in self.t_fc3.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, MU_WEI_INIT_G2_t_fcs, STD_WEI_INIT_G2_t_fcs)
            if 'bias' in name:
                # print(1)
                nn.init.constant_(param, val=0.0)
        '''

        # ======  mask
        self.mask = mask  # mask  实现交替couplinglayer

    def forward(self, x):  # 求逆+计算雅可比矩阵行列式，由数据样本 到 高斯输入
        x_m = x * self.mask

        # ==s_fcs网络
        s_out = self.s_fc1(x_m)
        for module_s in self.dense_block_s:
            s_out = module_s(s_out)
        s_out = self.s_fc3(s_out)     #             相当于log(beta)，，torch.exp(s_out)相当于beta

        # ==t_fcs网络
        t_out = self.t_fc1(x_m)
        for module_t in self.dense_block_t:
            t_out = module_t(t_out)
        t_out = self.t_fc3(t_out)

        y = x_m + (1 - self.mask) * (x * torch.exp(s_out) + t_out)  # x1-->xd 和 xd+1-->xD，s_out的激活函数相当于是exp(*),因此直接累加s_out.sum(dim=1)计算log_det_jacobian；但是exp限制了s_out网络只能输出正的，缩小了网络的表达能力；在G2网络中可以采用该激活函数。
        log_det_jacobian = (s_out * (1 - self.mask)).sum(dim=1)  # s_out相对于exp(s_out)已经计算了log,,  是否应该只计算一半s_out的累加？
        # y = x_m + (1 - self.mask) * (x * s_out + t_out)  # s_fcs网络（相乘的系数beta）改为线性激活，提高网络预测能力
        # log_det_jacobian =  (torch.log( torch.abs (s_out) + 1e-30 )* (1 - self.mask)).sum(dim=1)   #只计算一半s_out的累加,  对mini-batch累加，维数[1,numvar]

        return y, log_det_jacobian  # y取值范围负无穷到正无穷




    def backward(self, y):  # 采样，由高斯输入 到  数据样本
        y_m = y * self.mask

        # ==s_fcs网络
        s_out = self.s_fc1(y_m)
        for module in self.dense_block_s:
            s_out = module(s_out)
        s_out = self.s_fc3(s_out)  # 相当于log(beta)，，torch.exp(s_out)相当于beta

        # ==t_fcs网络
        t_out = self.t_fc1(y_m)
        for module_t in self.dense_block_t:
            t_out = module_t(t_out)
        t_out = self.t_fc3(t_out)

        x = y_m + (1 - self.mask) * (y - t_out) * torch.exp(-s_out)  # x = y_m + (1 - self.mask) * (y - t_out) ./torch.exp(s_out)  #等效           #相除、分母要不等于0
        # x = y_m + (1 - self.mask) * (y - t_out) / (s_out) #     #相除、分母要不等于0

        # print( x.shape) #[5,2]
        return x


class SMNET(nn.Module):
    # 建立递增网络
    def __init__(self, input_size, group_num, group_size):
        super().__init__()
        self.layer_one = nn.Linear(input_size, group_num * group_size,bias=True)  # 将64个神经元，分为4组,每一组有16个神经元
        self.sigmoid = nn.Sigmoid()

        self.input_size = input_size
        self.group_num = group_num
        self.group_size = group_size
        self.groups = locals()
        self.group_maxs = locals()

        # self.betap = None  #define a list of indenpent betap
        self.betap = nn.Parameter(-1 * torch.ones(self.group_num), requires_grad=True)
        self.betan = nn.Parameter(torch.tensor(-1.0), requires_grad=True)

        for name, param in self.layer_one.named_parameters():
            # print(name,param)
            if 'weight' in name:
                nn.init.normal_(param, 0.0, 1.0)
                # print(1)
            if 'bias' in name:
                # print(2)
                # nn.init.constant_(param, val=0.0)
                nn.init.normal_(param, 0.0, 1.0)

    def LSEN(self, xg):
        '''
        k=1时为正beta
        k=-1时为负beta
        '''

        # beta = k * torch.exp(nn.Parameter(torch.tensor(-1.0), requires_grad=True))
        # beta = nn.Parameter(    k * torch.exp(torch.tensor(-1.0))   ,    requires_grad=True)
        # beta = nn.Parameter(torch.tensor(-1.0), requires_grad=True)
        # beta=  torch.exp( nn.Parameter(torch.tensor( -1.0) , requires_grad=True)  )
        # beta=  nn.Parameter(torch.randn(1,2), requires_grad=True)
        # torch.log(beta)
        # print('betan', self.betan)
        c =  1e-8
        # c=torch.max(xg,dim=1).values
        # c=torch.reshape(torch.max(xg,dim=1).values, (-1, 1))
        # print(c.shape)
        # aa=torch.mul(xg, self.betap)
        # print(aa.shape)

        # torch.mul(a,beta)-c
        expout = torch.exp(torch.mul(xg, (-1.0 * torch.exp(self.betan))) - c)
        sumout = torch.sum(expout, dim=1)
        logout = torch.log(sumout)
        LSE = 1 / (-1.0 * torch.exp(self.betan)) * (c + logout)
        # print('self.betan', self.betan)

        return torch.reshape(LSE, (-1, 1))


    # forward这里就是神经网络的输入了
    def forward(self, input_x):
        length = len(input_x)
        input_x = self.layer_one(input_x)  # torch.Size([4, 64]);  torch.Size([batchsize, 64])

        # =====对层输出分组
        for i in range(0, self.group_num):
            self.groups['group%s' % i] = input_x[:, i * self.group_size: (i + 1) * self.group_size]  # shape:[10,1,16],一共有16组神经元;  torch.Size([4, 16])

        # ======第1层计算--正beta----然后取每一个group当中，输出值最大的神经元
        # if self.betap is None:
        #     self.betap=nn.Parameter(-1*torch.ones(self.group_num), requires_grad=True)
        #     # print('self.betapsize',self.betap.shape)

        for i in range(0, self.group_num):
            #  i=0
            xg = self.groups['group%s' % i]
            # [r,l]=a.shape
            # x_LSEP = self.LSEP(xg)
            #===LSEP

            betap=self.betap[i]
            c = 1e-8
            expout = torch.exp(torch.mul(xg, (1.0 * torch.exp(betap))) - c)
            sumout = torch.sum(expout, dim=1)
            logout = torch.log(sumout)
            LSE = 1 / (1.0 * torch.exp(betap)) * (c + logout)
            x_LSEP =torch.reshape(LSE, (-1, 1))

            self.group_maxs['group_max%s' % i] = x_LSEP

        # print('betap',  self.betap)

        # =======第2层计算--负beta----然后找到这4组数据的最小值.每一个数据，只选取4个数据当中的一个
        max_group = self.group_maxs['group_max%s' % 0]
        for i in range(1, self.group_num):
            max_group = torch.cat((max_group, self.group_maxs['group_max%s' % (i)]), dim=1)  # 横着拼
        y = self.LSEN(max_group)

        # print('self.betap',self.betap)
        # print('self.betan', self.betan)

        return y



##===权重裁剪函数======
class WeightConstraint(object):
    #SMNET net
    def __init__(self):
        pass

    def __call__(self, module):
        if hasattr(module, 'weight')  and  hasattr(module, 'bias')  :
            # print("Entered")
            w = module.weight.data
            # w = w.clamp(-1.0, 1.0)
            w = w.clamp(0.0, 1e30)
            b=module.bias.data
            b= b.clamp(-1000.0, 1000.0)

            # print(w)
            # w = torch.exp(w)

            module.weight.data = w
            module.bias.data = b

            # print(w)


class WeightConstraintG1(object):
    def __init__(self):
        pass

    def __call__(self, module):
        if hasattr(module, 'weight')  and  hasattr(module, 'bias')  :
            # print("Entered")
            w = module.weight.data
            # w = w.clamp(-1.0, 1.0)
            b=module.bias.data
            # b= b.clamp(-2.0, 2.0)

            # print(w)
            # w = torch.exp(w)

            module.weight.data = w
            module.bias.data = b

            # print(w)


class WeightConstraintG2(object):
    def __init__(self):
        pass

    def __call__(self, module):
        if hasattr(module, 'weight')  and  hasattr(module, 'bias')  :
            # print("Entered")
            w = module.weight.data

            # w = w.clamp(-1.0, 1.0)
            b=module.bias.data
            # b= b.clamp(-1.0, 1.0)
            #
            # print(w)
            # w = torch.exp(w)

            module.weight.data = w
            module.bias.data = b

            # print(w)


class uncertainty_to_weigh_losses(nn.Module):
    def __init__(self, num_loss):
        super().__init__()
        self.num_loss = num_loss
        # self.weights = None  # define a list of indenpent betap
        self.weights = nn.Parameter(torch.ones(self.num_loss) / self.num_loss, requires_grad=True)
    # import torch.nn as nn
    def forward(self, loss_list):
        """
        所有任务的损失列表，为tensor格式
        :param loss_list:
        :return: tensor格式的综合损失
        """
        # if self.weights is None:
        #     self.weights=nn.Parameter(torch.ones(self.num_loss)/self.num_loss, requires_grad=True)
        #     # print('self.betapsize',self.betap.shape)

        final_loss = []
        for i in range(self.num_loss):
            final_loss.append(loss_list[i] / (2 * self.weights[i] ** 2) + torch.log(self.weights[i]))

        print('self.weights', self.weights)

        return sum(final_loss), final_loss, self.weights



##===搭建深度生成网络======
class RealNVP(nn.Module):
    def __init__(self, input_dim, output_dim,
                 hid_dim, num_layers_s, num_layers_t, mask, n_layers,
                 hid_dim_G2, num_layers_s_G2, num_layers_t_G2, mask_G2, n_layers_G2,
                 input_size, group_num, group_size):
        super().__init__()

        # 实例化G1递增网络
        assert n_layers >= 2, 'num of coupling layers should be greater or equal to 2'
        self.modules = []
        self.modules.append(CouplingLayer(input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, mask))
        for _ in range(n_layers - 2):
            mask = 1 - mask  # 交替变换
            self.modules.append(CouplingLayer(input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, mask))
        self.modules.append(CouplingLayer(input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, 1 - mask))
        self.module_list = nn.ModuleList(self.modules)


        # 实例化G2递增网络
        assert n_layers_G2 >= 2, 'num of coupling layers should be greater or equal to 2'
        self.modules_G2 = []
        self.modules_G2.append(CouplingLayer_G2(2, 2, hid_dim_G2, num_layers_s_G2, num_layers_t_G2, mask_G2))
        for _ in range(n_layers_G2 - 2):
            mask_G2 = 1 - mask_G2  # 交替变换
            self.modules_G2.append(CouplingLayer_G2(2, 2, hid_dim_G2, num_layers_s_G2, num_layers_t_G2, mask_G2))
        self.modules_G2.append(CouplingLayer_G2(2,2, hid_dim_G2, num_layers_s_G2, num_layers_t_G2, 1 - mask_G2))
        self.module_list_G2 = nn.ModuleList(self.modules_G2)

        # 实例化SMNET递增网络,实例化全连接递增网络
        self.FDNN = SMNET(input_size, group_num, group_size)

        #实例化SMNET
        self.UWLS4 = uncertainty_to_weigh_losses(3)    #4个loss加权
        self.UWLS2 = uncertainty_to_weigh_losses(1)    #2个loss加权
        self.UWLS1 = uncertainty_to_weigh_losses(1)    #1个loss加权

    #====调用G1网络===随机变量分布拟合
    def forward(self, x):  # 求逆+计算雅可比矩阵行列式
        ldj_sum = 0  # sum of log determinant of jacobian
        for module in self.module_list:
            x, ldj = module(x)  # 自动调用forward函数
            ldj_sum += ldj  # log_det_jacobian累加

        return x, ldj_sum

    def backward(self, z):  # 用于采样
        for module in reversed(self.module_list):
            z = module.backward(z)  # 手动调用backward函数
        return z

    #====调用G2网络===样本响应预测
    def forward_G2(self, x):  # 求逆+计算雅可比矩阵行列式
        ldj_sum = 0  # sum of log determinant of jacobian
        for module in self.module_list_G2:
            x, ldj = module(x)  # 自动调用forward函数
            ldj_sum += ldj  # log_det_jacobian累加

        return x, ldj_sum

    def backward_G2(self, z):  # 用于采样
        for module in reversed(self.module_list_G2):
            z = module.backward(z)  # 手动调用backward函数
        return z

    #====调用MNET网络===样本响应预测
    def fully_DNN(self, z0):
        # 定义全连接网络，根据z计算极限状态函数预测值
        g = self.FDNN(z0)
        # torch.cuda.empty_cache()
        return g

    #====调用UWLS网络===
    def uwls4(self, loss):
        # 定义全连接网络，根据z计算极限状态函数预测值
        [sum_final_loss, final_loss, weights] = self.UWLS4(loss)
        return sum_final_loss, final_loss, weights
    def uwls2(self, loss):
        # 定义全连接网络，根据z计算极限状态函数预测值
        [sum_final_loss, final_loss, weights] = self.UWLS2(loss)
        return sum_final_loss, final_loss, weights
    def uwls1(self, loss):
        # 定义全连接网络，根据z计算极限状态函数预测值
        [sum_final_loss, final_loss, weights] = self.UWLS1(loss)
        return sum_final_loss, final_loss, weights



##===数据真实概率密度函数======
def data_distribution(numvar):
    # Loss3-1===计算真实概率密度logP==
    # 正态分布的均值和标准差
    # 当有多种概率分布时，可分别定义多个概率分布
    mu1 = np.zeros((numvar, 1), dtype=np.float64)
    sigma1 = np.ones((numvar, 1), dtype=np.float64)

    mu1[0, 0] = 1
    mu1[1, 0] = 1
    mu1[2, 0] = 0.1
    mu1[3, 0] = 0.5
    mu1[4, 0] = 1
    mu1[5, 0] = 1

    sigma1[0, 0] = 0.05
    sigma1[1, 0] = 0.1
    sigma1[2, 0] = 0.01
    sigma1[3, 0] = 0.05
    sigma1[4, 0] = 0.2
    sigma1[5, 0] = 0.2


    # 正态分布-所对应的正态分布的  均值和标准差
    X1_LOC = np.zeros((numvar, 1))  # 对数正态分布函数  的  输入参数
    X1_SIGMA = np.zeros((numvar, 1))  # 对数正态分布参数  的  输入参数

    X1_LOC[0:numvar, 0] = mu1[0:numvar, 0]  # 正态分布对应的均值，即函数的参数
    X1_SIGMA[0:numvar, 0] = sigma1[0:numvar, 0]  # 正态分布对应的标准差，即函数的参数

    X1_LOC = np.squeeze(X1_LOC, axis=1)
    X1_SIGMA = np.squeeze(X1_SIGMA, axis=1)

    loc = torch.from_numpy(X1_LOC).to(device)
    scale = torch.from_numpy(X1_SIGMA).to(device)

    # 建立多个相对独立的对x数正态分布，计算logP
    px_real = distributions.Normal(loc, scale)  # 定义目标真实概率密度函数，多维相互独立概率分布  (即使取失效区域的样本训练，条件概率密度大于完整分布的概率密度，也可以采用原始概率密度函数计算loss)

    return px_real

p_data = data_distribution(numvar)

##===输入先验分布-高斯分布概率密度函数======

meanz=torch.zeros(int(numvar)).to(device)
eyez=torch.eye(int(numvar)).to(device)
prior_z = distributions.MultivariateNormal(meanz,eyez)  # torch.eye(int(numvar)) 为协方差，而不是标准差




# =====实例化一个深度生成网络model======
for i in range(1):
    # ==== 制作mask =====，实现coupling layer交替
    mask0 = np.zeros((1, numvar))
    maskn = int(numvar / 2)
    mask0[0, 0:maskn] = 1
    mask = torch.from_numpy(mask0.astype(np.float64))  # 将numpy数组转化为pytorch tensor，定义一个mask实现输入数据拆分交替变换 coupling layer
    mask = 1 - mask  # 交替变换
    mask=mask.to(device)

    mask0_G2 = np.zeros((1, 2))
    # maskn_G2 = int(numvar / 2)
    mask0_G2[0, 1] = 1
    mask_G2 = torch.from_numpy(mask0_G2.astype(np.float64))  # 将numpy数组转化为pytorch tensor，定义一个mask实现输入数据拆分交替变换 coupling layer
    mask_G2 = 1 - mask_G2  # 交替变换
    mask_G2=mask_G2.to(device)

    constraints = WeightConstraint()  # 权重裁剪，保持为正
    constraintsG1 = WeightConstraintG1()  # 权重裁剪，
    constraintsG2 = WeightConstraintG2()  # 权重裁剪，

    # UWLS4=uncertainty_to_weigh_losses(4)

    model_initial = RealNVP(INPUT_DIM, OUTPUT_DIM,
                            HIDDEN_DIM, NUM_LAYERS_S, NUM_LAYERS_T, mask, N_COUPLE_LAYERS,
                            HIDDEN_DIM_G2, NUM_LAYERS_S_G2, NUM_LAYERS_T_G2, mask_G2, N_COUPLE_LAYERS_G2,
                            INPUT_SIZE, GROUP_NUM, GROUP_SIZE)
    # print(model_initial)
    # print(model_initial.FDNN)
    # print(model.module_list)
    model_initial=model_initial.to(device)




# ===============================  3 训练生成网络   =============================
# --- train and test --- #
# 单个epoch训练
def train(epoch, train_data1, train_data2, model,
          loss1_his,loss2_his,loss3_his,loss4_his,loss_his,
          weight_loss1,weight_loss2 ,weight_loss3,weight_loss4,
          N_STEP_G1,N_STEP_MNET,N_STEP_G2,
          loss_G2_his,
          lr_initial,lr_G2_initial,lr_mnet_initial):
    # 训练一个epoch,输入epoch编号、训练数据numpy格式train_data
    # print(epoch)
    # print(lr_initial)
    '''

    epoch=0
    train_data1 = dataset1  # 训练集
    train_data2 = dataset2  # 训练集
    model = model_initial

    loss1_his = []  # 保存损失函数值loss1  #训练误差
    loss2_his = []  # 保存损失函数值loss2
    loss3_his = []  # 保存损失函数值loss3
    loss4_his = []  # 保存损失函数值loss4
    loss_his = []  # 保存损失函数值loss
    loss_G2_his = []  # 保存损失函数值loss4

    '''


    train_loss = []   #batch loss
    batch_size=BATCH_SIZE

    #检查数据
    data1 = train_data1
    if data1.shape[0]==0:
        # print('data1为空，增加label的样本数N')
        data1=np.zeros((1, numvar + 2))    # XO + Y + X2 + label
    data2 = train_data2
    if data2.shape[0]==0:
        # print('data2为空，增加unlabel的样本数N')
        data2 = np.zeros((1, numvar + 2))  # XO + Y + X2 + unlabel

    #设置数据类型标签
    label1 = np.ones((np.shape(data1)[0], 1))   #第1类有标签数据
    label2 = np.ones((np.shape(data2)[0], 1)) *2  #第2类无标签数据
    data1 = np.hstack((data1, label1))
    data2 = np.hstack((data2, label2))

    #随机分组minibatch
    data_loader1 = torch.utils.data.DataLoader(data1, batch_size= batch_size, shuffle=True,drop_last=False)  # shuffle每个epoch打乱样本；drop_las丢掉剩余不足一个批次的数据；
    data_loader2 = torch.utils.data.DataLoader(data2, batch_size= batch_size, shuffle=True,drop_last=True)    # shuffle每个epoch打乱样本；drop_las丢掉剩余不足一个批次的数据（不足的丢掉）；

    batch_data1 = []  #提取随机batch数据
    for batch_idx, data in enumerate(data_loader1):
        # print(batch_idx)
        batch_data1.append(data)
    batch_data2 = []  #提取随机batch数据
    for batch_idx, data in enumerate(data_loader2):
        # print(batch_idx)  #当数据集中的样本数小于batchsize时，不会抽取batch。
        batch_data2.append(data)
    batch_data=[]
    batch_data.extend(batch_data1)
    batch_data.extend(batch_data2)   #合并两种数据的篇batch数据
    random.shuffle(batch_data)    # 打乱batch
    num_batch = len(batch_data)   # 计算总批次

    #===保存step loss
    loss1_his =loss1_his  # 保存损失函数值loss1  #训练误差
    loss2_his = loss2_his  # 保存损失函数值loss2
    loss3_his = loss3_his  # 保存损失函数值loss3
    loss4_his =loss4_his  # 保存损失函数值loss4
    loss_his = loss_his  # 保存损失函数值loss

    for batch_index in range(1,num_batch+1):  # 对所有数据学习一次

        #  batch_index=0

        # ==== 依次选取minibatch
        mini_batch=batch_data[batch_index-1]
        # ==G1网络样本
        x_mini_batch = np.reshape(mini_batch[:,0:numvar],(-1,numvar))   #随机变量样本
        # ==G2网络样本
        y_mini_batch = np.reshape(mini_batch[:,numvar],(-1,1))   #极限状态函数g(C)
        x2_mini_batch = np.reshape(mini_batch[:, numvar+1], (-1, 1))  # 构造随机变量输入a


        x_mini_batch = x_mini_batch.to(device)
        y_mini_batch = y_mini_batch.to(device)
        x2_mini_batch = x2_mini_batch.to(device)



        #=====采用data1训练，有标签
        if mini_batch[0,numvar+2]==1 :    #当前batch为data1，采用data1训练，有标签，改为2
            # print('data1')

            #====================  1  更新整个网络module_list+FDNN(or only updat G1) ================
            for step_G1_mnet in range(N_STEP_G1):  #训练1步
                # print(1)

                #===定义优化器
                for k in model.module_list.parameters():      #激活网络参数（避免上一个循环将其冻结）
                    k.requires_grad = True
                for k in model.module_list_G2.parameters():    #激活G2网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = False
                for k in model.FDNN.parameters():  # 激活MNET网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = True
                for k in model.UWLS4.parameters():  # 激活MNET网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = True
                params=filter(lambda p: p.requires_grad, model.parameters())  #过滤参数
                # optimizer1 = torch.optim.Adam(params,lr=lr_initial)  # 分别定义两个模块学习率
                optimizer1 = torch.optim.Adam([{'params': model.module_list.parameters()},
                                               {'params': model.FDNN.parameters(), 'lr': lr_mnet_initial},
                                               {'params': model.module_list_G2.parameters(), 'lr': lr_G2_initial},
                                               {'params': model.UWLS4.parameters(), 'lr': lr_initial}],
                                               lr=lr_initial)  # 分别定义两个模块学习率

                # print(list(model.UWLS4.parameters()))  # output []
                '''
                #检查网络参数是否冻结
                for name,value in model.named_parameters():
                    print(name,value.requires_grad)
                '''

                #==计算loss===
                # ====Loss1  G1网络====     生成网络概率密度
                z, log_det_j_sum = model(x_mini_batch)  # 自动调用forward函数，求逆+计算雅可比矩阵行列式
                # print( 'z',  z.shape)
                # print(' z, log_det_j_sum', log_det_j_sum.shape)
                # print('prior_z.log_prob(z)', prior_z.log_prob(z).shape)



                loss1 = -(prior_z.log_prob(z)+log_det_j_sum)    #logP(G)=prior_z.log_prob(z)+log_det_j_sum ；   log pi(z)=prior_z.log_prob(z)
                # loss1_his.append(weight_loss1*loss1.detach().numpy())
                # loss1 =torch.clamp(loss1, 3.0,100)  #先单个进行裁剪，然后在求平均值；概率密度最大值0.04，可得-logP最小值3.2
                loss1 = torch.clamp(loss1, loss1_low, loss1_up) # 先单个进行裁剪，然后在求平均值；概率密度最大值0.04，可得-logP最小值3.2;概率密度最大值1200，可得-logP最小值-7.09;
                loss1 = loss1.mean()  # logP(G)=prior_z.log_prob(z)+log_det_j_sum ；   log pi(z)=prior_z.log_prob(z)；；




                # ====Loss2  G1+MNET网络==== 输出与单调性网络的一致性
                loss_func2 = torch.nn.MSELoss()  # this is for regression mean squared loss
                # y_real = model.lsfn(y_mini_batch)  # 归一化的真实极限状态函数
                y_real = ((y_mini_batch - m_init) / (std_init + 0))  # 归一化的真实极限状态函数,std_init一般不为0
                y_pre = model.fully_DNN(torch.reshape(z[:, 0], (-1, 1)))  # 根据z采用递增DNN的预测极限状态函数（归一化的）
                loss2 = loss_func2(torch.reshape(y_pre, (-1, 1)),torch.reshape(y_real, (-1, 1)))  # must be (1. nn output, 2. target)
                # loss2_his.append(weight_loss2 * loss2.detach().numpy())  # 本身计算了平均值，不需要除以BATCH_SIZE


                # ====Loss3  G1网络====  预测概率密度形状约束
                x_inputs = Variable(x_mini_batch, requires_grad=True)   #转化为可求导输入

                # Loss3-1===计算真实概率密度logP==
                # p_data=data_distribution(numvar)
                log_p_real=p_data.log_prob(x_inputs)      # （对于包含多种概率分布的情况，可分别建立多个概率分别模型） x_inputs来源于数据，肯定大于0，满足对数正态分布logp要求；  真实概率密度函数的对数  log f(x) ;  这里是多个独立的对数正态概率分布，对数正态分布输出维数[bathsize, numvar]；而多维正态分布输出[batchsize,1]
                log_p_real =torch.sum(log_p_real,axis=1)       # 输出[batchsize,1], 累加多维分布联合概率密度的对数；（对于包含多种概率分布的情况，可分别建立多个概率分别模型，然后求和）
                # print('log_p_real.shape',log_p_real.shape)

                # Loss3-2===计算预测概率密度logP==
                z1, log_det_j_sum1 = model(x_inputs)  # 自动调用forward函数，求逆+计算雅可比矩阵行列式
                log_p_pred = prior_z.log_prob(z1)+log_det_j_sum1             #预测概率密度函数的对数  log fp(x);  z, log_det_j_sum = model(data[:,0:numvar] )

                # Loss3-3===计算loss
                log_w=log_p_real - log_p_pred    #真实概率密度函数  与 预测概率密度函数  比值的对数
                grad_log_w = torch.autograd.grad(outputs=log_w, inputs=x_inputs,grad_outputs=torch.ones(log_w.size()).to(device))[0]   #[batchsize,2]
                # print("grad_log_w.shape", grad_log_w.shape)  #[batchsize,2]
                grad_log_w_norm2 = torch.norm(grad_log_w, p=2, dim=1)   #d对每个样本的梯度求2范数
                # print("grad_log_w_norm2.shape", grad_log_w_norm2.shape)  # [batchsize]
                grad_log_w_norm2_m = torch.mean(grad_log_w_norm2)  #d对所以样本的梯度求2范数，计算平均  ；# [1]
                # print(grad_log_w_norm2_m)

                loss3=grad_log_w_norm2_m
                # loss3_his.append(weight_loss3 * loss3.detach().numpy())  # 本身计算了平均值，不需要除以BATCH_SIZE

                # ====Loss4  G2网络====G2单调网络输出的离散性约束
                dis_y_pre = F.pdist(y_pre, p=2).mean()  # 各样本距离的平均
                loss4 = -dis_y_pre
                # loss4_his.append(weight_loss4 * loss4.detach().numpy())  # 本身计算了平均值，不需要除以BATCH_SIZE
                # print('loss4',weight_loss4*loss4.detach().numpy())


                # ====weight Loss_all====


                loss = weight_loss1*loss1 + weight_loss2*loss2+ weight_loss3*loss3+weight_loss4*loss4
                # loss = weight_loss1 * loss1 + weight_loss2 * loss2 + weight_loss3 * loss3   #（不限制离散性，在MNET网络单独更新中，同样会主动拟合样本样本响应）
                loss=torch.clamp(loss, loss_low,loss_up)   #裁剪loss
                loss_his.append(loss.detach().cpu().numpy())

                '''
                #===loss进行加权
                # import torch
                loss_list=[]
                loss_list.append(loss1)
                loss_list.append(loss2)
                loss_list.append(loss3)
                # loss_list.append(loss4)
                [loss_sum, loss_list_weight, uncertainty_weight] = model.uwls4(loss_list)

                # ===提取权重的loss
                loss =loss_sum
                loss = torch.clamp(loss, loss_low, loss_up)  # 裁剪loss
                loss_his.append(loss.detach().cpu().numpy())
                loss1 = loss_list_weight[0]
                loss2 = loss_list_weight[1]
                loss3 = loss_list_weight[2]
                # loss4 = loss_list_weight[3]

                # print(list(loss.parameter()))
                # print('uncertainty_weight',uncertainty_weight)
                # print('loss1',loss1)
                # print('loss1.detach().cpu().numpy()', loss1.detach().cpu().numpy())

                '''


                #====保存权重后的loss
                # lll=np.reshape(loss1.detach().cpu().numpy(), (1,)  )
                loss1_his.append( np.reshape(loss1.detach().cpu().numpy(), (1,)  )   )
                loss2_his.append( np.reshape(   loss2.detach().cpu().numpy() , (1,)) )  # 本身计算了平均值，不需要除以BATCH_SIZE
                loss3_his.append( np.reshape(    loss3.detach().cpu().numpy(), (1,))   )  # 本身计算了平均值，不需要除以BATCH_SIZE
                loss4_his.append(np.reshape(    loss4.detach().cpu().numpy(), (1,)) )  # 本身计算了平均值，不需要除以BATCH_SIZE
                # print('111--loss1.detach().cpu().numpy(),shape',     lll.shape )

                # ====training ====
                optimizer1.zero_grad()
                loss.backward()
                cur_loss = loss.item()
                train_loss.append(cur_loss)
                nn.utils.clip_grad_norm_(model.parameters(),max_norm=MAX_NORM,norm_type=2)  #按照梯度范数裁剪
                optimizer1.step()
                # scheduler.step()  #折减学习率

                # ===FDNN网络进行裁剪梯度====
                model._modules['FDNN'].apply(constraints)
                model._modules['module_list'].apply(constraintsG1)
                model._modules['module_list_G2'].apply(constraintsG2)

                #===打印当前step结果
                # print(batch_index)
                if batch_index % STEP_LOSS_PRINT == 0:
                    # print(11)
                    print('Train Epoch: {} [{}/{} ({:.0f}%)]'.format(
                        epoch, (batch_index) * batch_size, (data1.shape[0] + data2.shape[0]),
                               100. * (batch_index) * batch_size / (data1.shape[0] + data2.shape[0]), ),'loss: ', loss.item(),\
                        'loss1: ',  loss1.item(),
                        'loss2: ', loss2.item(),
                        'loss3: ',  loss3.item(),
                        'loss4: ', loss4.item(),
                        'lr1:', optimizer1.state_dict()['param_groups'][0]['lr'])


            # ===================  2   更新部分递增网络SMNET-采用当前batch训练样本  ======================
            for step_mnet in range (N_STEP_MNET):  #训练N_STEP_MNET步
                # print('epoch',epoch, 'step_mnet',step_mnet )
                # ===定义优化器
                for k in model.module_list.parameters():  # 激活网络参数（避免上一个循环将其冻结）
                    k.requires_grad = False
                for k in model.module_list_G2.parameters():  # 激活G2网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = False
                for k in model.FDNN.parameters():  # 激活MNET网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = True
                for k in model.UWLS2.parameters():  # 激活MNET网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = True
                params = filter(lambda p: p.requires_grad, model.parameters())  # 过滤参数
                # optimizer2 = torch.optim.Adam(params, lr=lr_mnet_initial)  # 分别定义两个模块学习率
                optimizer2 = torch.optim.Adam([{'params': model.module_list.parameters()},
                                               {'params': model.FDNN.parameters(), 'lr': lr_mnet_initial},
                                               {'params': model.module_list_G2.parameters(), 'lr': lr_G2_initial},
                                               {'params': model.UWLS2.parameters(), 'lr': lr_initial}],
                                               lr=lr_initial)  # 分别定义两个模块学习率
                '''
                #检查网络参数是否冻结
                for name,value in model.named_parameters():
                    print(name,value.requires_grad)
                '''

                # 计算loss===
                # ====Loss1==== G1  生成网络概率密度
                z, log_det_j_sum = model(x_mini_batch)  # 自动调用forward函数，求逆+计算雅可比矩阵行列式
                # print( 'z',  z.shape)
                # print(' z, log_det_j_sum', log_det_j_sum.shape)
                # print('prior_z.log_prob(z)', prior_z.log_prob(z).shape)
                loss1 = -(prior_z.log_prob(z)+log_det_j_sum).mean()     #logP(G)=prior_z.log_prob(z)+log_det_j_sum ；   log pi(z)=prior_z.log_prob(z)
                # loss1_his.append(weight_loss1*loss1.detach().numpy())
                loss1 =torch.clamp(loss1, -10,10)

                # ====Loss2==== G1+SMNET 输出与单调性网络的一致性
                loss_func2 = torch.nn.MSELoss()  # this is for regression mean squared loss
                # y_real = model.lsfn(y_mini_batch)  # 归一化的真实极限状态函数
                y_real = ((y_mini_batch - m_init) / (std_init + 0))  # 归一化的真实极限状态函数,std_init一般不为0
                y_pre = model.fully_DNN(torch.reshape(z[:, 0], (-1, 1)))  # 根据z采用递增DNN的预测极限状态函数（归一化的）
                loss2 = loss_func2(torch.reshape(y_pre, (-1, 1)),torch.reshape(y_real, (-1, 1)))  # must be (1. nn output, 2. target)
                # loss2_his.append(weight_loss2 * loss2.detach().numpy())  # 本身计算了平均值，不需要除以BATCH_SIZE

                # ====Loss3====  预测概率密度形状约束
                x_inputs = Variable(x_mini_batch, requires_grad=True)  # 转化为可求导输入
                # Loss3-1===计算真实概率密度logP==
                # p_data = data_distribution(numvar)
                log_p_real = p_data.log_prob( x_inputs)  # （对于包含多种概率分布的情况，可分别建立多个概率分别模型） x_inputs来源于数据，肯定大于0，满足对数正态分布logp要求；  真实概率密度函数的对数  log f(x) ;  这里是多个独立的对数正态概率分布，对数正态分布输出维数[bathsize, numvar]；而多维正态分布输出[batchsize,1]
                log_p_real = torch.sum(log_p_real, axis=1)  # 输出[batchsize,1], 累加多维分布联合概率密度的对数；（对于包含多种概率分布的情况，可分别建立多个概率分别模型，然后求和）
                # print('log_p_real.shape',log_p_real.shape)
                # Loss3-2===计算预测概率密度logP==
                z1, log_det_j_sum1 = model(x_inputs)  # 自动调用forward函数，求逆+计算雅可比矩阵行列式
                log_p_pred = prior_z.log_prob(z1) + log_det_j_sum1  # 预测概率密度函数的对数  log fp(x);  z, log_det_j_sum = model(data[:,0:numvar] )
                # Loss3-3===计算loss
                log_w = log_p_real - log_p_pred  # 真实概率密度函数  与 预测概率密度函数  比值的对数
                grad_log_w = torch.autograd.grad(outputs=log_w, inputs=x_inputs, grad_outputs=torch.ones(log_w.size()).to(device))[0]  # [batchsize,2]
                # print("grad_log_w.shape", grad_log_w.shape)  #[batchsize,2]
                grad_log_w_norm2 = torch.norm(grad_log_w, p=2, dim=1)  # d对每个样本的梯度求2范数
                # print("grad_log_w_norm2.shape", grad_log_w_norm2.shape)  # [batchsize]
                grad_log_w_norm2_m = torch.mean(grad_log_w_norm2)  # d对所以样本的梯度求2范数，计算平均  ；# [1]
                # print(grad_log_w_norm2_m)
                loss3 = grad_log_w_norm2_m
                # loss3_his.append(weight_loss3 * loss3.detach().numpy())  # 本身计算了平均值，不需要除以BATCH_SIZE

                # ====Loss4====MNET单调网络输出的离散性约束
                dis_y_pre = F.pdist(y_pre, p=2).mean()  # 各样本距离的平均
                loss4 = -dis_y_pre
                # loss4_his.append(weight_loss4 * loss4.detach().numpy())  # 本身计算了平均值，不需要除以BATCH_SIZE
                # print('loss4',weight_loss4*loss4.detach().numpy())

                # ====Loss_all====(loss1和loss3对MNET没影响)

                loss = weight_loss2 * loss2  + weight_loss4 * loss4
                # loss = weight_loss2 * loss2
                loss = torch.clamp(loss, loss_low, loss_up)  # 裁剪loss
                loss_his.append(loss.detach().cpu().numpy())

                '''
                # ===loss进行加权
                # import torch
                loss_list = []
                # loss_list.append(loss1)
                loss_list.append(loss2)
                # loss_list.append(loss3)
                # loss_list.append(loss4)
                [loss_sum, loss_list_weight, uncertainty_weight] = model.uwls2(loss_list)

                # ===提取权重的loss
                loss = loss_sum
                loss = torch.clamp(loss, loss_low, loss_up)  # 裁剪loss
                loss_his.append(loss.detach().cpu().numpy())
                # loss1 = loss_list_weight[0]
                loss2 = loss_list_weight[0]
                # loss3 = loss_list_weight[2]
                # loss4 = loss_list_weight[1]
                '''

                #====保存权重后的loss
                # qqq=np.reshape( loss1.detach().cpu().numpy() , (1,))
                loss1_his.append( np.reshape( loss1.detach().cpu().numpy() , (1,)) )
                loss2_his.append(np.reshape( loss2.detach().cpu().numpy() , (1,)) )  # 本身计算了平均值，不需要除以BATCH_SIZE
                loss3_his.append(np.reshape( loss3.detach().cpu().numpy() , (1,)) )  # 本身计算了平均值，不需要除以BATCH_SIZE
                loss4_his.append(np.reshape(loss4.detach().cpu().numpy(), (1,))  )  # 本身计算了平均值，不需要除以BATCH_SIZE
                # print('222--loss1.detach().cpu().numpy(),shape',qqq.shape)


                # ====training ====
                optimizer2.zero_grad()
                loss.backward()
                cur_loss = loss.item()
                train_loss.append(cur_loss)
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=MAX_NORM, norm_type=2)  # 按照梯度范数裁剪
                optimizer2.step()
                # scheduler.step()  #折减学习率

                # ===FDNN网络进行裁剪权重====
                model._modules['FDNN'].apply(constraints)
                model._modules['module_list'].apply(constraintsG1)
                model._modules['module_list_G2'].apply(constraintsG2)




                # ===打印当前step结果
                # print(batch_index)
                if batch_index % STEP_LOSS_PRINT == 0:
                    # print(11)
                    print('Train Epoch: {} [{}/{} ({:.0f}%)]'.format(
                        epoch, (batch_index) * batch_size, (data1.shape[0] + data2.shape[0]),
                               100. * (batch_index) * batch_size / (data1.shape[0] + data2.shape[0]), ),'loss: ', loss.item(),\
                        'loss1: ', weight_loss1 * loss1.item(),
                        'loss2: ',weight_loss2 * loss2.item(),
                        'loss3: ', weight_loss3 * loss3.item(),
                        'loss4: ',weight_loss4 * loss4.item(),
                        'lr2:',  optimizer2.state_dict()['param_groups'][0]['lr'])


            # ===================  3   更新部分递增网络G2-采用当前batch训练样本  ======================
            for step_G2 in range (N_STEP_G2):  #训练N_STEP_G2步
                # print('epoch',epoch, 'step_G2',step_G2 )
                # ===定义优化器
                for k in model.module_list.parameters():  # 激活网络参数（避免上一个循环将其冻结）
                    k.requires_grad = False
                for k in model.module_list_G2.parameters():  # 激活G2网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = True
                for k in model.FDNN.parameters():  # 激活G2网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = False
                for k in model.UWLS1.parameters():  # 激活MNET网络参数 （避免上一个循环将其冻结）
                    k.requires_grad = True
                params = filter(lambda p: p.requires_grad, model.parameters())  # 过滤参数
                # optimizer3 = torch.optim.Adam(params, lr=lr_G2_initial)  # 分别定义两个模块学习率
                optimizer3 = torch.optim.Adam([{'params': model.module_list.parameters()},
                                               {'params': model.FDNN.parameters(), 'lr': lr_mnet_initial},
                                               {'params': model.module_list_G2.parameters(), 'lr': lr_G2_initial},
                                              {'params': model.UWLS1.parameters(), 'lr': lr_initial}],
                                              lr=lr_initial)  # 分别定义两个模块学习率
                '''
                #检查网络参数是否冻结
                for name,value in model.named_parameters():
                    print(name,value.requires_grad)
                '''

                # ==计算loss===
                z, log_det_j_sum = model(x_mini_batch)  # 自动调用forward函数，求逆+计算雅可比矩阵行列式

                # ====Loss2  G1+G2网络==== 输出与单调性网络的一致性
                loss_func2 = torch.nn.MSELoss()  # this is for regression mean squared loss
                # G2网络输入
                x_mini_batch_G2 = torch.hstack((torch.reshape(z[:, 0], (-1, 1)), x2_mini_batch))  # G2网络输入  z1+a
                # G2网络输出真实值
                # g_real = ((y_mini_batch - m_init) / (std_init + 1e-20))  # 归一化的真实极限状态函数
                g_real = model.fully_DNN(torch.reshape(z[:, 0], (-1, 1)))  # 根据z采用递增DNN的预测极限状态函数（归一化的）
                y_mini_batch_G2 = torch.hstack((g_real, x2_mini_batch))  # G2网络输出真实值  ， g(x)+b,也就是g(x)+a
                # G2网络输出预测值
                y_pre = model.backward_G2(x_mini_batch_G2)  # 根据z1+a采用递增G2的预测  b+极限状态函数g(x)（归一化的）,   手动调用backward，采用backward采样

                loss2 = loss_func2(y_pre, y_mini_batch_G2)  # must be (1. nn output, 2. target)
                # loss_G2_his.append(weight_loss2 * loss2.detach().numpy())  # 本身计算了平均值，不需要除以BATCH_SIZE


                # ====Loss_all====(loss1和loss3对MNET没影响)

                loss = loss2
                loss = torch.clamp(loss, loss_low, loss_up)  # 裁剪loss
                # loss_his.append(loss.detach().numpy())

                '''
                # ===loss进行加权
                # import torch

                loss_list = []
                # loss_list.append(loss1)
                loss_list.append(loss2)
                # loss_list.append(loss3)
                # loss_list.append(loss4)
                [loss_sum, loss_list_weight, uncertainty_weight] = model.uwls1(loss_list)


                # ===提取权重的loss
                loss = loss_sum
                loss = torch.clamp(loss, loss_low, loss_up)  # 裁剪loss
                loss_his.append(loss.detach().cpu().numpy())
                # loss1 = loss_list_weight[0]
                loss2 = loss_list_weight[0]
                # loss3 = loss_list_weight[2]
                # loss4 = loss_list_weight[3]
                
                '''

                # ====保存权重后的loss
                loss_G2_his.append(weight_loss2 * loss2.detach().cpu().numpy())  # 本身计算了平均值，不需要除以BATCH_SIZE


                # ====training ====
                optimizer3.zero_grad()
                loss.backward()
                cur_loss = loss.item()
                train_loss.append(cur_loss)
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=MAX_NORM, norm_type=2)  # 按照梯度范数裁剪
                optimizer3.step()
                # scheduler.step()  #折减学习率


                # ===FDNN网络进行裁剪权重====
                model._modules['FDNN'].apply(constraints)
                model._modules['module_list'].apply(constraintsG1)
                model._modules['module_list_G2'].apply(constraintsG2)

                # ===打印当前step结果
                # print(batch_index)
                if batch_index % STEP_LOSS_PRINT == 0:
                    # print(11)
                    print('Train Epoch: {} [{}/{} ({:.0f}%)]'.format(
                        epoch, (batch_index) * batch_size, (data1.shape[0] + data2.shape[0]),
                               100. * (batch_index) * batch_size / (data1.shape[0] + data2.shape[0]), ),'loss: ', loss.item(),\
                        'loss_G2: ',weight_loss2 * loss2.item(),
                        'lr2:',  optimizer3.state_dict()['param_groups'][0]['lr'])


        #=====当前batch为data2，采用data2训练，无标签
        else:    #采用data2训练，无标签
            print('data2')

    train_loss=np.array(train_loss)  #每个step的平均loss
    train_loss=train_loss.mean()     #所有step的平均loss
    loss_epoch_ave=train_loss     #每个样本的平均loss(各个loss分项本身就进行了batch平均)
    print('====> Epoch: {} Average training loss: {:.4f}'.format(epoch, loss_epoch_ave ))#每一个样本的平均loss

    return train_loss,model,loss1_his,loss2_his,loss3_his,loss4_his,loss_his,loss_G2_his


def subfig_plot(data, d1,d2,  x_size, y_size, x_start, x_end, y_start, y_end, title, color,filename):

    plt.clf()
    plt.close('all')
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.figure(figsize=[x_size, y_size])
    plt.scatter(data[:, d1], data[:,d2], c=color, s=1)
    plt.xlim(x_start,x_end)
    plt.ylim(y_start,y_end)
    plt.xlabel('X0', fontproperties='Arial', fontsize=14)
    plt.ylabel('X1', fontproperties='Arial', fontsize=14)
    plt.title(title)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + filename)


def sample(z, model):
    model.eval()
    with torch.no_grad():
        # z = prior_z.sample((nsample,))   #生成随机高斯样本
        x = model.backward(z)     #手动调用backward，采用backward采样

        z1, log_det_j_sum = model(x)  # 自动调用forward函数，求逆+计算雅可比矩阵行列式
        # print(z1.shape, log_det_j_sum.shape)  # [batcsize, n_dimsion],  [batcsize]

        #采用真实高斯样本计算概率密度
        logprob = (prior_z.log_prob(z) + log_det_j_sum)   #prior_z需要与训练时的输入分布一致
        # print('logprob.shape',logprob.shape)

        px=torch.exp(logprob).cpu()
        px=np.reshape(px.numpy(),(-1,1))

        z = z.cpu().numpy()
        x = x.cpu().numpy()


    return  x,  z1.cpu().numpy(), logprob.cpu().numpy(),   px


# 训练最终的模型
def TrainModel(model_initial, dataset1, dataset2, epoch_optimal):

    '''
    model_initial = model_initial
    dataset1 = dataset1  # 训练集
    dataset2 = dataset2  # 训练集
    epoch_optimal=5
    '''

    train_data1 = dataset1  # 训练集
    train_data2 = dataset2  # 训练集

    model = model_initial
    epoch_max = epoch_optimal
    epoch_train_loss_his = []

    loss1_his = []  # 保存损失函数值loss1  #训练误差
    loss2_his = []  # 保存损失函数值loss2
    loss3_his = []  # 保存损失函数值loss3
    loss4_his = []  # 保存损失函数值loss4
    loss_his = []   # 保存损失函数值loss
    loss_G2_his=[]

    # for epoch in range(5000, 5500):
    print('TrainModel started!')
    lr_k=0.0  #等于0.01时，100epoch后学习率变为0.5倍
    # 训练G1+SMNET
    for epoch in range(model_load_epoch+1, model_load_epoch+epoch_max + 1):

        # ===训练====
        # if epoch < epoch_max:
        #学习率折减
        lr_initial=lr_initial0*(1.0/(1.0+epoch*lr_k))
        lr_G2_initial=lr_G2_initial0*(1.0/(1.0+epoch*lr_k))
        lr_mnet_initial=lr_mnet_initial0*(1.0/(1.0+epoch*lr_k))
        [train_loss_out, model_train, loss1_his, loss2_his, loss3_his, loss4_his, loss_his,loss_G2_his] = train(epoch,train_data1,train_data2,model,
                                                                                                loss1_his,loss2_his,loss3_his,loss4_his,loss_his,
                                                                                                weight_loss1,weight_loss2,weight_loss3,weight_loss4,
                                                                                                1,0,0,
                                                                                                loss_G2_his,
                                                                                                lr_initial,lr_G2_initial,lr_mnet_initial)
        model = model_train
        epoch_train_loss_his.append(train_loss_out)

        # =====抽样==========
        if epoch % EPOCH_DENSITY_PLOT == 0:

            #===抽样-计算预测概率密度===
            z_sample = prior_z.sample((10000,))  # 生成随机高斯样本   #生成随机高斯样本
            [x_sample, z_predict, logprob, px] = sample(z_sample,model)
            # z_sample = z_sample.numpy()
            # px=np.reshape(px,(-1,1))

            # ===计算真实概率密度=====
            logpt = p_data.log_prob(torch.clamp(torch.from_numpy(x_sample).to(device), logpt_input_low,logpt_input_up))  # 对数正态分布输出大于零，进行裁剪，不影响训练结果；正态分布不需要进行裁剪
            logpt = torch.sum(logpt,axis=1)  # 输出[batchsize,1]      #===================================================================================================
            # print('logpt2.shape', logpt.shape)
            # logpt_np = np.reshape(logpt.numpy(), (-1, 1))
            px_real = torch.exp(logpt)
            # px_real_np = np.reshape(px_real.numpy(), (-1, 1))

            for i in range(1):
                # 预测概率密度
                # import matplotlib.pyplot as plt
                # from mpl_toolkits.mplot3d import Axes3D
                plt.clf()
                plt.close('all')
                fig = plt.figure()
                ax = fig.gca(projection='3d')
                ax.scatter(x_sample[:, 0], x_sample[:, 1], px)
                plt.title('predicted_density')
                # plt.xlim(-10, 10)  # 设置X轴显示范围
                # plt.ylim(-10, 10)  # 设置Y轴显示范围
                # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
                # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
                plt.xlabel('X0', fontproperties='Arial', fontsize=14)
                plt.ylabel('X1', fontproperties='Arial', fontsize=14)
                # plt.show()
                plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/TrainModel_predicted_density-' + str(epoch) + '.png')

                # 真实概率密度
                plt.clf()
                plt.close('all')
                fig = plt.figure()
                ax = fig.gca(projection='3d')
                ax.scatter(x_sample[:, 0], x_sample[:, 1], px_real.cpu())
                plt.title('real_density')
                plt.xlim(-10, 10)  # 设置X轴显示范围
                plt.ylim(-10, 10)  # 设置Y轴显示范围
                # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
                # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
                # plt.title('Samples in 2 dimension space')
                plt.xlabel('X0', fontproperties='Arial', fontsize=14)
                plt.ylabel('X1', fontproperties='Arial', fontsize=14)
                # plt.show()
                plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/TrainModel_real_density-' + str(epoch) + '.png')

        if epoch % EPOCH_MODEL_SAVE == 0:
            torch.save({'model': model_train.state_dict()},LOG_DIR + '/Seq' + str(sequence) + '/InfoDGN_model_TrainModel'+ str(epoch) +'.pth')

    # 先 训练MNET
    for epoch in range( model_load_epoch + epoch_max + 1, model_load_epoch + epoch_max + 1 + N_STEP_MNET_):
        # 最后一步调整参数，使G2网络拟合数据
        # 学习率折减
        lr_initial = lr_initial0 * (1.0/(1.0+epoch*lr_k))
        lr_G2_initial = lr_G2_initial0 * (1.0/(1.0+epoch*lr_k))
        lr_mnet_initial = lr_mnet_initial0 * (1.0/(1.0+epoch*lr_k))
        [train_loss_out, model_train, loss1_his, loss2_his, loss3_his, loss4_his, loss_his,loss_G2_his] = train(epoch,train_data1,train_data2,model,
                                                                                                loss1_his,loss2_his,loss3_his,loss4_his,loss_his,
                                                                                                weight_loss1,weight_loss2,weight_loss3,weight_loss4_,
                                                                                                0, 1, 0,
                                                                                                loss_G2_his,
                                                                                                lr_initial,lr_G2_initial,lr_mnet_initial)

        model = model_train
        epoch_train_loss_his.append(train_loss_out)

        # =====抽样==========
        if epoch % EPOCH_DENSITY_PLOT == 0:

            #===抽样-计算预测概率密度===
            z_sample = prior_z.sample((10000,))  # 生成随机高斯样本   #生成随机高斯样本
            [x_sample, z_predict, logprob, px] = sample(z_sample,model)
            # z_sample = z_sample.numpy()
            # px=np.reshape(px,(-1,1))

            # ===计算真实概率密度=====
            logpt = p_data.log_prob(torch.clamp(torch.from_numpy(x_sample).to(device), logpt_input_low,logpt_input_up))  # 对数正态分布输出大于零，进行裁剪，不影响训练结果；正态分布不需要进行裁剪
            logpt = torch.sum(logpt,axis=1)  # 输出[batchsize,1]      #===================================================================================================
            # print('logpt2.shape', logpt.shape)
            # logpt_np = np.reshape(logpt.numpy(), (-1, 1))
            px_real = torch.exp(logpt)
            # px_real_np = np.reshape(px_real.numpy(), (-1, 1))

            for i in range(1):
                # 预测概率密度
                # import matplotlib.pyplot as plt
                # from mpl_toolkits.mplot3d import Axes3D
                plt.clf()
                plt.close('all')
                fig = plt.figure()
                ax = fig.gca(projection='3d')
                ax.scatter(x_sample[:, 0], x_sample[:, 1], px)
                plt.title('predicted_density')
                # plt.xlim(-10, 10)  # 设置X轴显示范围
                # plt.ylim(-10, 10)  # 设置Y轴显示范围
                # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
                # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
                plt.xlabel('X0', fontproperties='Arial', fontsize=14)
                plt.ylabel('X1', fontproperties='Arial', fontsize=14)
                # plt.show()
                plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/TrainModel_predicted_density-' + str(epoch) + '.png')

                # 真实概率密度
                plt.clf()
                plt.close('all')
                fig = plt.figure()
                ax = fig.gca(projection='3d')
                ax.scatter(x_sample[:, 0], x_sample[:, 1], px_real.cpu())
                plt.title('real_density')
                plt.xlim(-10, 10)  # 设置X轴显示范围
                plt.ylim(-10, 10)  # 设置Y轴显示范围
                # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
                # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
                # plt.title('Samples in 2 dimension space')
                plt.xlabel('X0', fontproperties='Arial', fontsize=14)
                plt.ylabel('X1', fontproperties='Arial', fontsize=14)
                # plt.show()
                plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/TrainModel_real_density-' + str(epoch) + '.png')

        if epoch % EPOCH_MODEL_SAVE == 0:
            torch.save({'model': model_train.state_dict()},LOG_DIR + '/Seq' + str(sequence) + '/InfoDGN_model_TrainModel'+ str(epoch) +'.pth')

    # 然后 训练G2
    for epoch in range(model_load_epoch + epoch_max + 1 + N_STEP_MNET_, model_load_epoch + epoch_max + 1 +  N_STEP_MNET_ + N_STEP_G2_ ):
        # 最后一步调整参数，使G2网络拟合数据
        # 学习率折减
        lr_initial = lr_initial0 * (1.0 / (1.0 + epoch * lr_k))
        lr_G2_initial = lr_G2_initial0 * (1.0 / (1.0 + epoch * lr_k))
        lr_mnet_initial = lr_mnet_initial0 * (1.0 / (1.0 + epoch * lr_k))
        [train_loss_out, model_train, loss1_his, loss2_his, loss3_his, loss4_his, loss_his, loss_G2_his] = train(epoch,
                                                                                                                 train_data1,train_data2,model,
                                                                                                                 loss1_his,loss2_his,loss3_his,loss4_his,loss_his,
                                                                                                                 weight_loss1,weight_loss2,weight_loss3,weight_loss4_,
                                                                                                                 0, 0,  1,
                                                                                                                 loss_G2_his,
                                                                                                                 lr_initial,lr_G2_initial,lr_mnet_initial)

        model = model_train
        epoch_train_loss_his.append(train_loss_out)

        # =====抽样==========
        if epoch % EPOCH_DENSITY_PLOT == 0:

            # ===抽样-计算预测概率密度===
            z_sample = prior_z.sample((10000,))  # 生成随机高斯样本   #生成随机高斯样本
            [x_sample, z_predict, logprob, px] = sample(z_sample, model)
            # z_sample = z_sample.numpy()
            # px=np.reshape(px,(-1,1))

            # ===计算真实概率密度=====
            logpt = p_data.log_prob(torch.clamp(torch.from_numpy(x_sample).to(device), logpt_input_low, logpt_input_up))  # 对数正态分布输出大于零，进行裁剪，不影响训练结果；正态分布不需要进行裁剪
            logpt = torch.sum(logpt, axis=1)  # 输出[batchsize,1]      #===================================================================================================
            # print('logpt2.shape', logpt.shape)
            # logpt_np = np.reshape(logpt.numpy(), (-1, 1))
            px_real = torch.exp(logpt)
            # px_real_np = np.reshape(px_real.numpy(), (-1, 1))

            for i in range(1):
                # 预测概率密度
                # import matplotlib.pyplot as plt
                # from mpl_toolkits.mplot3d import Axes3D
                plt.clf()
                plt.close('all')
                fig = plt.figure()
                ax = fig.gca(projection='3d')
                ax.scatter(x_sample[:, 0], x_sample[:, 1], px)
                plt.title('predicted_density')
                # plt.xlim(-10, 10)  # 设置X轴显示范围
                # plt.ylim(-10, 10)  # 设置Y轴显示范围
                # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
                # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
                plt.xlabel('X0', fontproperties='Arial', fontsize=14)
                plt.ylabel('X1', fontproperties='Arial', fontsize=14)
                # plt.show()
                plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/TrainModel_predicted_density-' + str(epoch) + '.png')

                # 真实概率密度
                plt.clf()
                plt.close('all')
                fig = plt.figure()
                ax = fig.gca(projection='3d')
                ax.scatter(x_sample[:, 0], x_sample[:, 1], px_real.cpu())
                plt.title('real_density')
                plt.xlim(-10, 10)  # 设置X轴显示范围
                plt.ylim(-10, 10)  # 设置Y轴显示范围
                # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
                # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
                # plt.title('Samples in 2 dimension space')
                plt.xlabel('X0', fontproperties='Arial', fontsize=14)
                plt.ylabel('X1', fontproperties='Arial', fontsize=14)
                # plt.show()
                plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/TrainModel_real_density-' + str(epoch) + '.png')

        if epoch % EPOCH_MODEL_SAVE == 0:
            torch.save({'model': model_train.state_dict()},
                       LOG_DIR + '/Seq' + str(sequence) + '/InfoDGN_model_TrainModel' + str(epoch) + '.pth')

    # ====保存模型====  # 方法2：只保存模型参数，新建相同的模型，然后导入参数
    # torch.save({'model': model_train.state_dict()},LOG_DIR + '/Seq' + str(sequence) + '/InfoDGN_model_TrainModel.pth')
    torch.save({'model': model_train.state_dict()},LOG_DIR + '/Seq' + str(sequence) + '/InfoDGN_model_TrainModel' + str(epoch_max) + '.pth')

    print('TrainModel finished!')

    return model_train, epoch_train_loss_his, loss1_his, loss2_his, loss3_his, loss4_his, loss_his,loss_G2_his





##==== 3-4    导入model参数=====
# model_load_epoch=1000
state_dict = torch.load(LOG_DIR + '/Seq' + str(sequence) + '/InfoDGN_model_TrainModel' + str(model_load_epoch) + '.pth')
model = model_initial
model.load_state_dict(state_dict['model'])
model_initial=model


epoch_optimal=EPOCHS_MAX

# =====训练最终的模型====
for i in range (1):
    [model_train,epoch_train_loss_his,loss1_his, loss2_his, loss3_his, loss4_his, loss_his,loss_G2_his]= TrainModel(model_initial, dataset1, dataset2, epoch_optimal)
    model=model_train

    #==保存loss等数据

    filename = LOG_DIR + '/Seq' + str(sequence) + '/TrainModel.npz'
    np.savez(filename, \
             m_init=m_init, \
             std_init=std_init, \
            )

    io.savemat(LOG_DIR + '/Seq'+str(sequence)+ '/TrainModel.mat',\
                       {'loss1_his':np.array(loss1_his),\
                        'loss2_his': np.array(loss2_his), \
                        'loss3_his': np.array(loss3_his), \
                        'loss4_his': np.array(loss4_his), \
                        'loss_his': np.array(loss_his), \
                        'loss_G2_his':np.array(loss_G2_his),\
                        'm_init': m_init,\
                        'std_init': std_init
                        })  # 只保存numpy数组格式的。列表保存后，matlab无法导入



'''
#查看网络参数
for name, param in model_train.module_list_G2[0].s_fc1.named_parameters():
    print(name, param)
    a=name
    b=param
    
'''


#========绘图 training loss====
for i in range(1):

    #====绘图loss1+loss2+loss3+loss4====
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('loss_functions')
    plt.plot(np.arange(len(loss1_his)), loss1_his,c='g')
    plt.plot(np.arange(len(loss2_his)), loss2_his,c='b')
    plt.plot(np.arange(len(loss3_his)), loss3_his,c='r')
    plt.plot(np.arange(len(loss4_his)), loss4_his,c='c')
    plt.plot(np.arange(len(loss_his)), loss_his,c='k')
    plt.legend(["loss1_his", "loss2_his", "loss3_his","loss4_his","loss_his"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('step', fontproperties='Arial', fontsize=14)
    plt.ylabel('loss', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/TrainModel_step_loss_ALL.png')


    #====绘图loss1+loss2+loss3+loss4====
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('loss_functions')
    plt.plot(np.arange(len(loss1_his)), loss1_his,c='g')
    # plt.plot(np.arange(len(loss2_his)), loss2_his,c='b')
    # plt.plot(np.arange(len(loss3_his)), loss3_his,c='r')
    # plt.plot(np.arange(len(loss4_his)), loss4_his,c='c')
    # plt.plot(np.arange(len(loss_his)), loss_his,c='k')
    plt.legend(["loss1_his"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('step', fontproperties='Arial', fontsize=14)
    plt.ylabel('loss', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/TrainModel_step_loss1.png')


    #====绘图loss1+loss2+loss3+loss4====
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('loss_functions')
    # plt.plot(np.arange(len(loss1_his)), loss1_his,c='g')
    plt.plot(np.arange(len(loss2_his)), loss2_his,c='b')
    # plt.plot(np.arange(len(loss3_his)), loss3_his,c='r')
    # plt.plot(np.arange(len(loss4_his)), loss4_his,c='c')
    # plt.plot(np.arange(len(loss_his)), loss_his,c='k')
    plt.legend(["loss2_his"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('step', fontproperties='Arial', fontsize=14)
    plt.ylabel('loss', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/TrainModel_step_loss2.png')


    #====绘图loss1+loss2+loss3+loss4====
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('loss_functions')
    # plt.plot(np.arange(len(loss1_his)), loss1_his,c='g')
    # plt.plot(np.arange(len(loss2_his)), loss2_his,c='b')
    plt.plot(np.arange(len(loss3_his)), loss3_his,c='r')
    # plt.plot(np.arange(len(loss4_his)), loss4_his,c='c')
    # plt.plot(np.arange(len(loss_his)), loss_his,c='k')
    plt.legend(["loss3_his"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('step', fontproperties='Arial', fontsize=14)
    plt.ylabel('loss', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/TrainModel_step_loss3.png')



    #====绘图loss1+loss2+loss3+loss4====
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('loss_functions')
    # plt.plot(np.arange(len(loss1_his)), loss1_his,c='g')
    # plt.plot(np.arange(len(loss2_his)), loss2_his,c='b')
    # plt.plot(np.arange(len(loss3_his)), loss3_his,c='r')
    plt.plot(np.arange(len(loss4_his)), loss4_his,c='c')
    # plt.plot(np.arange(len(loss_his)), loss_his,c='k')
    plt.legend(["loss4_his"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('step', fontproperties='Arial', fontsize=14)
    plt.ylabel('loss', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/TrainModel_step_loss4.png')




    #====绘图loss1+loss2+loss3+loss4====
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('loss_functions')
    # plt.plot(np.arange(len(loss1_his)), loss1_his,c='g')
    # plt.plot(np.arange(len(loss2_his)), loss2_his,c='b')
    # plt.plot(np.arange(len(loss3_his)), loss3_his,c='r')
    # plt.plot(np.arange(len(loss4_his)), loss4_his,c='c')
    plt.plot(np.arange(len(loss_his)), loss_his,c='k')
    plt.legend(["loss1_his", "loss2_his", "loss3_his","loss4_his","loss_his"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('step', fontproperties='Arial', fontsize=14)
    plt.ylabel('loss', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/TrainModel_step_loss_sum.png')


    #====绘图loss1+loss2+loss3+loss4====
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('loss_functions')
    # plt.plot(np.arange(len(loss1_his)), loss1_his,c='g')
    # plt.plot(np.arange(len(loss2_his)), loss2_his,c='b')
    # plt.plot(np.arange(len(loss3_his)), loss3_his,c='r')
    plt.plot(np.arange(len(loss_G2_his)), loss_G2_his,c='c')
    # plt.plot(np.arange(len(loss_his)), loss_his,c='k')
    plt.legend(["loss_G2_his"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('step', fontproperties='Arial', fontsize=14)
    plt.ylabel('loss', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/TrainModel_step_loss_G2.png')


    # ====绘图epoch mean loss====
    plt.clf()
    plt.close('all')
    fig = plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.title('loss_functions')
    # plt.plot(np.arange(len(loss1_his)), loss1_his,c='g')
    # plt.plot(np.arange(len(loss2_his)), loss2_his,c='b')
    # plt.plot(np.arange(len(loss3_his)), loss3_his,c='r')
    # plt.plot(np.arange(len(loss_G2_his)), loss_G2_his,c='c')
    # plt.plot(np.arange(len(loss_his)), loss_his,c='k')

    plt.plot(np.arange(len(epoch_train_loss_his)), epoch_train_loss_his, c='k')

    plt.legend(["epoch_train_loss_his"], loc=2, ncol=2)  # 设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('step', fontproperties='Arial', fontsize=14)
    plt.ylabel('loss', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/TrainModel_epoch_train_loss_his.png')

# =============================================  4 生成网络采样   =======================================================

#===== 4.1   G1网络 随机采样   ====
for i in range(1):
    z_sample =prior_z.sample((10000,))   #生成随机高斯样本   #生成随机高斯样本
    [x_sample,  z_predict, logprob, px]=sample(z_sample,model)
    z_sample=z_sample.cpu().numpy()

    #====4.2 计算真实概率密度=====
    # p_data = data_distribution(numvar)  # 多个相互独立的概率分步
    # p_data = distributions.MultivariateNormal(torch.zeros(numvar), torch.eye(int(numvar))*4)  # torch.eye(int(numvar)) 为协方差，而不是标准差
    # (即使取失效区域的样本训练，条件概率密度大于完整分布的概率密度，但形状是一样的)

    logpt = p_data.log_prob(torch.clamp(torch.from_numpy(x_sample).to(device), logpt_input_low, logpt_input_up))        #对数正态分布输出大于零，进行裁剪，不影响训练结果；正态分布不需要进行裁剪
    logpt = torch.sum(logpt, axis=1)  # 输出[batchsize,1]      #===================================================================================================
    # print('logpt2.shape', logpt.shape)

    logpt_np=np.reshape(logpt.cpu().numpy(),(-1,1))
    px_real=torch.exp(logpt)
    px_real_np=np.reshape(px_real.cpu().numpy(),(-1,1))



    #预测概率密度
    # import matplotlib.pyplot as plt
    # from mpl_toolkits.mplot3d import Axes3D
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    ax=fig.gca(projection='3d')
    ax.scatter(x_sample[:, 0], x_sample[:, 1], px)
    plt.title('predicted_density')
    # plt.xlim(-10, 10)  # 设置X轴显示范围
    # plt.ylim(-10, 10)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.xlabel('X0', fontproperties='Arial', fontsize=14)
    plt.ylabel('X1', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR +  '/Seq' + str(sequence) +'/predicted_density.png')


    #真实概率密度
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    ax=fig.gca(projection='3d')
    ax.scatter(x_sample[:, 0], x_sample[:, 1], px_real.cpu())
    plt.title('real_density')
    plt.xlim(-10, 10)  # 设置X轴显示范围
    plt.ylim(-10, 10)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('X0', fontproperties='Arial', fontsize=14)
    plt.ylabel('X1', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/real_density.png')


#===== 4.2 验算样本响应与随机输入的关系====
for i in range(1):
    import C0_LSF
    y_sample=np.reshape(C0_LSF.Z(x_sample[:, 0:numvar]),(-1,1))  # 计算真实功能函数
    # y_sample.shape
    # y_sample_n=model.lsfn(torch.from_numpy(y_sample)).detach().numpy()   #归一化真实响应
    y_sample_n = ((y_sample - m_init) / (std_init + 1e-20))  # 归一化的真实极限状态函数


    #采用递增网络，根据z预测计算极限状态函数的拟合值
    # G2网络输入
    x_sample_input_G2 = torch.hstack((torch.reshape(torch.from_numpy(z_sample[:, 0]).to(device), (-1, 1)), torch.zeros(( np.shape(z_sample)[0] ,1)).to(device)))  # G2网络输入  z1+a,a取均值0

    # G2网络输出预测值
    y_sample_pre0= model.backward_G2(x_sample_input_G2)  # 根据z1+a采用递增G2的预测  b+极限状态函数g(x)（归一化的）,  输出g(x)+b；  手动调用backward，采用backward采样,  y_mini_batch_G2 =torch.hstack( ( g_real,x2_mini_batch )) #G2网络输出真实值  ， g(x)+b,也就是g(x)+a
    y_sample_pre=np.reshape(y_sample_pre0[:,0].cpu().detach(),(-1,1))  # 根据z计算预测功能函数(归一化的g（x）)
    # y_sample_pre.cpu()
    # MNET网络输出预测值
    # y_sample_pre_MNET = model.fully_DNN(torch.reshape(torch.from_numpy(z_sample[:, 0]).to(device), (-1, 1)))  #++++++++++++++++++++++++++++++++++++++++++++++++暂用内存大
    # z_input=torch.reshape(torch.from_numpy(z_sample[:, 0]).to(device), (-1, 1))
    # with torch.no_grad():
    #     y_sample_pre_MNET = model.fully_DNN(z_input)
    # del z_input
    # model.to_empty()
    # y_sample_pre_MNET = np.reshape(y_sample_pre_MNET.cpu().detach(), (-1, 1))  # 根据z计算预测功能函数

    y_sample_pre_MNET = model.fully_DNN(torch.reshape(torch.from_numpy(z_sample[:, 0]).to(device), (-1, 1)))
    y_sample_pre_MNET = np.reshape(y_sample_pre_MNET.cpu().detach(), (-1, 1))  # 根据z计算预测功能函数


    #绘制 随机输入z+真实样本响应（归一化）   #绘制 随机输入z+预测样本响应
    #=====================
    plt.clf()
    plt.close('all')
    mpl.rcParams['font.size'] = 14     #需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  #需要在fig前面定义
    plt.figure(figsize=[6,6])

    plt.scatter(z_sample[:,0], y_sample_pre, s=5,c='r',marker='.')   #总体中剩余样本中  失效的样本
    plt.scatter(z_sample[:,0], y_sample_n, s=5,c='b',marker='.')   #总体中剩余样本中  失效的样本
    plt.scatter(z_sample[:,0], y_sample_pre_MNET, s=5,c='y',marker='.')   #总体中剩余样本中  失效的样本

    plt.legend(["y_pre_G2", 'y_n_real' ,'y_pre_SMNET'], loc=2, ncol=2)   #设置图例
    plt.xlim(-6, 6)   #设置X轴显示范围
    plt.ylim(-6, 6)   #设置Y轴显示范围
    # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.title('z[:,0] TO g(x)')
    plt.xlabel('z',fontproperties='Arial', fontsize=14)
    plt.ylabel('g(x)_normalizion',fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/z_to_gx_prey_and_sample_n.png')


    plt.clf()
    plt.close('all')
    mpl.rcParams['font.size'] = 14     #需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  #需要在fig前面定义
    plt.figure(figsize=[6,6])

    plt.scatter(z_sample[:,0], y_sample_pre, s=5,c='r',marker='.')   #总体中剩余样本中  失效的样本
    # plt.scatter(z_sample[:,0], y_sample_n, s=5,c='b',marker='.')   #总体中剩余样本中  失效的样本
    plt.scatter(z_sample[:,0], y_sample_pre_MNET, s=5,c='y',marker='.')   #总体中剩余样本中  失效的样本

    plt.legend(["y_pre_G2", 'y_pre_SMNET'], loc=2, ncol=2)   #设置图例
    plt.xlim(-6, 6)   #设置X轴显示范围
    plt.ylim(-6, 6)   #设置Y轴显示范围
    # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.title('z[:,0] TO g(x)')
    plt.xlabel('z',fontproperties='Arial', fontsize=14)
    plt.ylabel('g(x)_normalizion',fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/z_to_gx_prey.png')





    #绘制 随机输入z+真实样本响应
    #=====================
    plt.clf()
    plt.close('all')
    mpl.rcParams['font.size'] = 14     #需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  #需要在fig前面定义
    plt.figure(figsize=[6,6])
    plt.scatter(z_sample[:,0], y_sample, s=5,c='r',marker='.')   #总体中剩余样本中  失效的样本
    plt.legend(["samples"], loc=2, ncol=2)   #设置图例
    plt.xlim(-6, 6)   #设置X轴显示范围
    plt.ylim(-6, 15)   #设置Y轴显示范围
    # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.title('z[:,0] TO g(x)')
    plt.xlabel('z',fontproperties='Arial', fontsize=14)
    plt.ylabel('g(x)',fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/z_to_y_sample.png')



    #绘制 预测样本响应+真实样本响应（归一化的）
    #=====================
    plt.clf()
    plt.close('all')
    mpl.rcParams['font.size'] = 14     #需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  #需要在fig前面定义
    plt.figure(figsize=[6,6])
    plt.scatter(y_sample_pre, y_sample_n, s=5,c='r',marker='.')   #总体中剩余样本中  失效的样本
    plt.legend(["samples"], loc=2, ncol=2)   #设置图例
    plt.xlim(-6, 6)   #设置X轴显示范围
    plt.ylim(-6, 6)   #设置Y轴显示范围
    # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('z[:,0]_NI TO g(x)')
    plt.xlabel('y_sample_pre',fontproperties='Arial', fontsize=14)
    plt.ylabel('y_sample_n',fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/y_sample_pre_to_y_sample_n.png')

    # ax.plot_surface   (x[:, 0],x[:, 1],px.re)




    #====绘图z_and_gx====
    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    # plt.title('loss_functions')
    plt.plot(np.arange(z_sample[:,0].shape[0]), z_sample[:,0],c='r')
    plt.plot(np.arange(y_sample_n.shape[0]), y_sample_n,c='b')
    plt.legend(["z[:,0]", "g(x)_normalizion"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('z[:,0]', fontproperties='Arial', fontsize=14)
    plt.ylabel('g(x)_normalizion', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/z_and_gx.png')


    plt.clf()
    plt.close('all')
    fig=plt.figure()
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    # plt.title('loss_functions')
    plt.plot(np.arange(z_sample[:,0].shape[0]), z_sample[:,0],c='r')
    # plt.plot(np.arange(y_sample_n.shape[0]), y_sample_n,c='b')
    plt.legend(["z[:,0]"], loc=2, ncol=2)   #设置图例
    # plt.xlim(-6, 6)  # 设置X轴显示范围
    # plt.ylim(-6, 6)  # 设置Y轴显示范围
    # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    # plt.title('Samples in 2 dimension space')
    plt.xlabel('z[:,0]', fontproperties='Arial', fontsize=14)
    plt.ylabel('g(x)_normalizion', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/z_sample.png')




# ========================================  5 根据z选择性采样   ====================================
#===5.1  设置不同z的区间===
for i in range(1):
    n_s=10000
    z_sample = prior_z.sample((n_s,))  # 生成随机高斯样本   #生成随机高斯样本
    z_sample_np = z_sample.cpu().numpy()
    z_index=torch.argsort(z_sample[:,0],dim=0)
    z_sample_sort=z_sample[z_index,:]
    z_sample_sort_np=z_sample_sort.cpu().numpy()


    for i in range(0,n_s,int(0.2*n_s)):
        [x_sample, z_predict, logprob, px] = sample(z_sample_sort[i:int(i+0.2*n_s),:],model)

        #==z_sample==
        plt.clf()
        plt.close('all')
        # px=np.reshape(px,(-1,1))
        mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
        mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
        plt.figure(figsize=[10, 10])
        plt.scatter(z_sample_sort[i:int(i+0.2*n_s),0].cpu(),z_sample_sort[i:int(i+0.2*n_s),1].cpu(), s=5, c='r', marker='.')  # 总体中剩余样本中  失效的样本
        plt.legend(["samples"], loc=2, ncol=2)  # 设置图例
        plt.xlim(-10, 10)   #设置X轴显示范围
        plt.ylim(-10, 10)   #设置Y轴显示范围
        # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
        # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
        plt.title('z_sample')
        plt.xlabel('z0', fontproperties='Arial', fontsize=14)
        plt.ylabel('z1', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/z_sample'+str(i)+'.png')


        # ==x_sample==
        plt.clf()
        plt.close('all')
        # px=np.reshape(px,(-1,1))
        mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
        mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
        plt.figure(figsize=[10, 10])
        plt.scatter(x_sample[:, 0], x_sample[:, 1], s=5, c='b', marker='.')  # 总体中剩余样本中  失效的样本
        plt.legend(["samples"], loc=2, ncol=2)  # 设置图例
        plt.xlim(-10, 10)   #设置X轴显示范围
        plt.ylim(-10, 10)   #设置Y轴显示范围
        # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
        # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
        plt.title('x_sample')
        plt.xlabel('x0', fontproperties='Arial', fontsize=14)
        plt.ylabel('x1', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/x_sample'+str(i)+'.png')



    [x_sample, z_predict, logprob, px] = sample(z_sample_sort,model)

    #==z_sample==
    plt.clf()
    plt.close('all')
    # px=np.reshape(px,(-1,1))
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.figure(figsize=[10, 10])
    plt.scatter(z_sample_sort[:,0].cpu(),z_sample_sort[:,1].cpu(), s=5, c='r', marker='.')  # 总体中剩余样本中  失效的样本
    plt.legend(["samples"], loc=2, ncol=2)  # 设置图例
    plt.xlim(-10, 10)   #设置X轴显示范围
    plt.ylim(-10, 10)   #设置Y轴显示范围
    # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.title('z_sample')
    plt.xlabel('z0', fontproperties='Arial', fontsize=14)
    plt.ylabel('z1', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/z_sample_ALL.png')


    # ==x_sample==
    plt.clf()
    plt.close('all')
    # px=np.reshape(px,(-1,1))
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.figure(figsize=[10, 10])
    plt.scatter(x_sample[:, 0], x_sample[:, 1], s=5, c='b', marker='.')  # 总体中剩余样本中  失效的样本
    plt.legend(["samples"], loc=2, ncol=2)  # 设置图例
    plt.xlim(-10, 10)   #设置X轴显示范围
    plt.ylim(-10, 10)   #设置Y轴显示范围
    # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.title('x_sample')
    plt.xlabel('x0', fontproperties='Arial', fontsize=14)
    plt.ylabel('x1', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/x_sample_ALL.png')



#===5.2  固定z为常数 ===

for i in range(1):
    n_s=10000
    z_sample = prior_z.sample((n_s,))  # 生成随机高斯样本   #生成随机高斯样本
    z_sample_np = z_sample.cpu().numpy()
    index=torch.argsort(z_sample[:,0],dim=0)
    z_sample_sort=z_sample[index,:]
    z_sample_sort_np=z_sample_sort.cpu().numpy()
    for i in range(0, n_s, int(0.2 * n_s)):
        z_sample_sort[i:int(i + 0.2 * n_s), 0] = z_sample_sort[i, 0]  # 将第1列设置为常熟



    for i in range(0,n_s,int(0.2*n_s)):

        [x_sample, z_predict, logprob, px] = sample(z_sample_sort[i:int(i+0.2*n_s),:],model)

        #==z_sample==
        plt.clf()
        plt.close('all')
        # px=np.reshape(px,(-1,1))
        mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
        mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
        plt.figure(figsize=[10, 10])
        plt.scatter(z_sample_sort[i:int(i+0.2*n_s),0].cpu(),z_sample_sort[i:int(i+0.2*n_s),1].cpu(), s=5, c='r', marker='.')  # 总体中剩余样本中  失效的样本
        plt.legend(["samples"], loc=2, ncol=2)  # 设置图例
        plt.xlim(-10, 10)   #设置X轴显示范围
        plt.ylim(-10, 10)   #设置Y轴显示范围
        # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
        # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
        plt.title('z_sample')
        plt.xlabel('z0', fontproperties='Arial', fontsize=14)
        plt.ylabel('z1', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/constantZ_z_sample'+str(i)+'.png')


        # ==x_sample==
        plt.clf()
        plt.close('all')
        # px=np.reshape(px,(-1,1))
        mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
        mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
        plt.figure(figsize=[10, 10])
        plt.scatter(x_sample[:, 0], x_sample[:, 1], s=5, c='b', marker='.')  # 总体中剩余样本中  失效的样本
        plt.legend(["samples"], loc=2, ncol=2)  # 设置图例
        plt.xlim(-10, 10)   #设置X轴显示范围
        plt.ylim(-10, 10)   #设置Y轴显示范围
        # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
        # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
        plt.title('x_sample')
        plt.xlabel('x0', fontproperties='Arial', fontsize=14)
        plt.ylabel('x1', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/constantZ_x_sample'+str(i)+'.png')



#===5.2  固定z为0 ===
for i in range(1):
    n_s=10000
    z_sample = prior_z.sample((n_s,))  # 生成随机高斯样本   #生成随机高斯样本
    z_sample_np = z_sample.cpu().numpy()
    index=torch.argsort(z_sample[:,0],dim=0)
    z_sample_sort=z_sample[index,:]
    z_sample_sort_np=z_sample_sort.cpu().numpy()
    z_sample_sort[:, 0] = 0.0  # 将第1列设置为常熟


    [x_sample, z_predict, logprob, px] = sample(z_sample_sort,model)

    #==z_sample==
    plt.clf()
    plt.close('all')
    # px=np.reshape(px,(-1,1))
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.figure(figsize=[10, 10])
    plt.scatter(z_sample_sort[i:int(i+0.2*n_s),0].cpu(),z_sample_sort[i:int(i+0.2*n_s),1].cpu(), s=5, c='r', marker='.')  # 总体中剩余样本中  失效的样本
    plt.legend(["samples"], loc=2, ncol=2)  # 设置图例
    plt.xlim(-10, 10)   #设置X轴显示范围
    plt.ylim(-10, 10)   #设置Y轴显示范围
    # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.title('z_sample')
    plt.xlabel('z0', fontproperties='Arial', fontsize=14)
    plt.ylabel('z1', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/constantZ0_z_sample'+str(i)+'.png')


    # ==x_sample==
    plt.clf()
    plt.close('all')
    # px=np.reshape(px,(-1,1))
    mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
    mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
    plt.figure(figsize=[10, 10])
    plt.scatter(x_sample[:, 0], x_sample[:, 1], s=5, c='b', marker='.')  # 总体中剩余样本中  失效的样本
    plt.legend(["samples"], loc=2, ncol=2)  # 设置图例
    plt.xlim(-10, 10)   #设置X轴显示范围
    plt.ylim(-10, 10)   #设置Y轴显示范围
    # plt.xticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
    # plt.yticks(np.linspace(-6,6,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
    plt.title('x_sample')
    plt.xlabel('x0', fontproperties='Arial', fontsize=14)
    plt.ylabel('x1', fontproperties='Arial', fontsize=14)
    # plt.show()
    plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/constantZ0_x_sample'+str(i)+'.png')























