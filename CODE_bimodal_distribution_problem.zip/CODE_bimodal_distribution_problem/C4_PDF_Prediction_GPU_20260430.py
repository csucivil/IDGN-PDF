


# def IS(seq,res):

'''

seq = 4  # 连续抽样轮编号
res = 3 # 实验编号

'''

seq = 4  # 连续抽样轮编号
res =11  # 实验编号
numduofeng = 1  # 多峰变量数目


import torch
from torch import nn, optim, distributions
from torch.nn import functional as F
from torch.autograd import Variable
from torchvision import transforms
from torchvision.utils import save_image

from sklearn import datasets
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from pylab import rcParams
import os
import random
from scipy import io
from scipy.stats import norm

sequence = seq  # 连续抽样轮编号
result = res  # 实验编号




# =================================  定义文件路径创建函数    =========================================
LOG_DIR = 'F:/XZL_Research/python_work/FLOW_PDF/example14/results' + str(result)
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


# 函数
def mkdir(path):
    import os
    path = path.strip()  # 去除首位空格
    path = path.rstrip("\\")  # 去除尾部 \ 符号
    isExists = os.path.exists(path)  # 判断路径是否存在

    # 判断结果
    if not isExists:
        os.makedirs(path)  # 如果不存在则创建目录


# # 调用函数
path = LOG_DIR  # 创建文件夹
mkdir(path)
path = LOG_DIR + '/Seq' + str(sequence)  # 创建文件夹
mkdir(path)
# ===================================================================================


# ===================0 计算参数  ===============================================


#===================0 导数训练参数  ===============================================
filename_TrainModel = LOG_DIR + '/Seq' + str(sequence-2) + '/TrainModel.npz'
dataTrainModel = np.load(filename_TrainModel)
m_init = dataTrainModel['m_init']     # 极限状态函数g(x)均值
std_init = dataTrainModel['std_init'] # 极限状态函数g(x)标准差


##==========2 导入深度生成网络模型(将C2_InfoDGN中对应的代码复制到这里)==============
# model_epoch = dataTrainModel['EPOCHS_MAX'] #导入的model文件编号（根据EPOCH_MODEL_SAVE取值）
model_epoch =6500   #导入的model文件编号（根据EPOCH_MODEL_SAVE取值）

for i in range(1):
    ##==创建相同的model类

    # ===============================  0 参数   =============================
    for i in range(1):
        # 导入模型的epoch
        # model_load_epoch = 600

        # ====== 1== 整个网络（响应预测模型）
        # --- data loading --- #
        # 导入样本X
        filename_MCS = LOG_DIR + '/Seq1/sampledata1.npz'
        dataMCS = np.load(filename_MCS)
        numvar = int(dataMCS['numvar'])

        # --- configuration --- #
        EPOCHS_MAX = 0  # 交叉验证最大epoch数
        BATCH_SIZE = 500  # batchsize要大于交叉验证的num_fold，否则当dataset2无标签数据为空时，交叉验证会引入一些全为0的数据集
        MAX_NORM = 1e20  # 梯度范数裁剪
        STEP_LOSS_PRINT = 100  # print loss的间隔step数( =样本数N/批样本数/每个epoch打印次数 )
        EPOCH_DENSITY_PLOT = 20  # 画图-预测概率密度+真实概率密度--的间隔epoch数
        EPOCH_MODEL_SAVE = 100  # 保存模型的epoch频率

        weight_loss1 = 1.0  # loss1的权重系数   生成网络概率密度
        weight_loss2 = 0.5  # loss2的权重系数   输出单调性
        weight_loss3 = 0.0  # loss3的权重系数   预测概率密度形状约束
        weight_loss4 = 0.0  # loss4的权重系数   MNET单调网络输出的离散性约束
        weight_loss4_ = 0.0  # loss4的权重系数(最后一epoch)
        lr_weights = 1e-4  # weights初始学习率

        logpt_input_low = 1e-30  # logp的输入裁剪下界，只在绘图中设置，不影响训练结果，对数正态分布大于零，正态分布为负无穷
        logpt_input_up = 1e30  # logp的输入裁剪下界，只在绘图中设置，不影响训练结果，

        # ====== 1== G1网络（随机变量概率分布拟合）
        INPUT_DIM = numvar  # couplelayer  输入单元数
        OUTPUT_DIM = numvar  # couplelayer  输出单元数
        HIDDEN_DIM = 256 * 1  # couplelayer  隐层单元数
        NUM_LAYERS_S = 5  # couplelayer  S网络层数
        NUM_LAYERS_T = 5  # couplelayer  T网络层数
        N_COUPLE_LAYERS = 20  # couplelayer  嵌套个数
        # SAVE_PLT_INTERVAL = 5

        lr_initial0 = 1e-5  # 初始学习率
        # lr_step_size = 500  # 学习率折减step数，不是epoch
        # lr_gamma = 1.0  # 学习率折减系数

        loss1_low = -7.5  # clamp loss1,   裁剪loss1范围，避免特别小地负数，导致loss2不起作用，根据训练样本中最大样本概率密度计算loss1下限，-log（pdf）
        loss1_up = 100  #

        # ====== 4== SMNET 网络（响应预测模型）
        INPUT_SIZE = 1  # MNET网络输入层节点数（输出层默认1）
        GROUP_NUM = 300  # MNET网络分组数量
        GROUP_SIZE = 300  # MNET网络每组节点数
        lr_mnet_initial0 = 1e-3  # MNET网络初始学习率

        # N_STEP_MNET = 1    # 在每个step中G2网络额外训练的步数
        N_STEP_MNET_ = 200  # 在每个step中G2网络额外训练的步数(最后一epoch)

        # ====== 3== G2网络（响应预测模型）
        HIDDEN_DIM_G2 = 256 * 1  # couplelayer  隐层单元数
        NUM_LAYERS_S_G2 = 5  # couplelayer  S网络层数
        NUM_LAYERS_T_G2 = 5  # couplelayer  T网络层数
        N_COUPLE_LAYERS_G2 = 10  # couplelayer  嵌套个数

        loss_low = -10000  # loss裁剪下界，避免出现NAN
        loss_up = 10000  # loss裁剪上界，避免出现NAN
        lr_G2_initial0 = 1e-4  # G2网络初始学习率
        # N_STEP_G2 = 1    # 在每个step中G2网络额外训练的步数
        N_STEP_G2_ = 200  # 在每个step中G2网络额外训练的步数(最后一epoch)

        torch.set_default_dtype(torch.float64)
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')  # 判断是否有GPU，定义计算设备，  后面视乎没有调用GPU的命令？

    # ===============================  1 导入MCS数据-data1-label   =============================

    # ====================  1-1 data1-label 带标签  ===================
    for i in range(1):

        # --- data loading --- #
        # 导入样本X
        filename_MCS = LOG_DIR + '/Seq1/sampledata1.npz'
        dataMCS = np.load(filename_MCS)

        N1 = dataMCS['N']
        N = N1
        numvar = int(dataMCS['numvar'])
        XO = dataMCS['XO']
        X2 = dataMCS['X2']
        Y = dataMCS['Y']
        # Pf_MCS = dataMCS['Pf_MCS']   #用于计算条件概率密度
        Pf_MCS = 1.0  # 用于计算条件概率密度

        XDEN = dataMCS['XDEN']
        XDEN_Joint = np.ones((N, 1))  # 计算联合概率密度
        for i in range(0, numvar):
            XDEN_Joint[:, 0] = XDEN_Joint[:, 0] * XDEN[:, i]

        XDEN_Joint = XDEN_Joint / Pf_MCS  # 条件概率密度
        # XDEN_Joint=XDEN[:,0]*XDEN[:,1]

        dataset = np.zeros((N, numvar + 2))  # XO + Y + X2
        dataset[:, 0:numvar] = XO[:, 0:numvar]
        dataset[:, numvar] = Y[:, 0]
        dataset[:, numvar + 1] = X2[:, 0]
        dataset1 = dataset.astype(np.float64)

        # 计算归一化参数初始值
        m_init = np.mean(dataset1[:, numvar])  # 极限状态函数均值
        std_init = 1.0 * np.std(dataset1[:, numvar])  # 极限状态函数标准差

        # 训练数据概率密度
        # import matplotlib.pyplot as plt
        # from mpl_toolkits.mplot3d import Axes3D
        plt.clf()
        plt.close('all')
        fig = plt.figure()
        ax = fig.gca(projection='3d')
        ax.scatter(dataset1[:, 0], dataset1[:, 1], XDEN_Joint)
        plt.title('training data_density')
        plt.xlim(-10, 10)  # 设置X轴显示范围
        plt.ylim(-10, 10)  # 设置Y轴显示范围
        # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
        # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
        plt.xlabel('X0', fontproperties='Arial', fontsize=14)
        plt.ylabel('X1', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/traning_data_density.png')

        '''
        p_data = distributions.MultivariateNormal(torch.zeros(numvar), torch.eye(numvar)*4)   # torch.eye(int(numvar)) 为协方差，而不是标准差
        # xt=torch.from_numpy(np.array([0,0]))
        # logpt=p_data.log_prob(xt)
        # pt=torch.exp(logpt)
        '''

        '''
        train_data =datasets.make_moons(n_samples=50000, noise=.05)[0].astype(np.float64)
        test_data = datasets.make_moons(n_samples=1000, noise=.05)[0].astype(np.float64)
        '''

        '''
        # 直方图检查数据
        d=0
        plt.figure(figsize=[6, 6])
        plt.hist(train_data[:, d], 100, density=True)  # 直方图
        plt.xlim(-6, 6)  # 设置X轴显示范围
        # plt.ylim(-6, 6)  # 设置Y轴显示范围
        plt.xlabel(u'd)', fontproperties='Arial', fontsize=14)
        plt.ylabel(u'Probability density', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence)+ '/训练数据直方图d='+str(d)+'.png')

        '''

        # 绘制二维离散点
        # =====================
        plt.clf()
        plt.close('all')
        mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
        mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
        plt.figure(figsize=[10, 10])
        plt.scatter(dataset1[:, 0], dataset1[:, 1], s=5, c='r', marker='.')  # 总体中剩余样本中  失效的样本
        # plt.legend(["Failure", "Save"], loc=2, ncol=2)  # 设置图例
        plt.xlim(-10, 10)  # 设置X轴显示范围
        plt.ylim(-10, 10)  # 设置Y轴显示范围
        # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
        # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
        # plt.title('Samples in 2 dimension space')
        plt.xlabel('X0', fontproperties='Arial', fontsize=14)
        plt.ylabel('X1', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/train_data_from_0and1_dimension.png')

        # ===检查训练样本的极限状态函数分布范围
        train_data_torch = torch.from_numpy(dataset1)
        aa = torch.argsort(train_data_torch[:, numvar], dim=0)
        train_data_g_sort = train_data_torch[aa, :]
        train_data_g_sort_np = train_data_g_sort.numpy()
        train_data_g_sort_np_n = np.reshape((train_data_g_sort_np[:, numvar] - m_init) / (std_init + 1e-20), (-1, 1))

        # 实际未归一化
        plt.clf()
        plt.close('all')
        fig = plt.figure()
        mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
        mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
        plt.title('train_data_g_sort_np')
        plt.plot(np.arange(np.shape(train_data_g_sort_np)[0]), train_data_g_sort_np[:, numvar], c='b')
        plt.legend(["train_data_g_sort_np"], loc=2, ncol=2)  # 设置图例
        # plt.xlim(-6, 6)  # 设置X轴显示范围
        # plt.ylim(-6, 6)  # 设置Y轴显示范围
        # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
        # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
        # plt.title('Samples in 2 dimension space')
        plt.xlabel('N', fontproperties='Arial', fontsize=14)
        plt.ylabel('train_data_g_sort_np', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/train_data_g_sort_np.png')

        # 归一化
        plt.clf()
        plt.close('all')
        fig = plt.figure()
        mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
        mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
        plt.title('train_data_g_sort_np_n')
        plt.plot(np.arange(np.shape(train_data_g_sort_np_n)[0]), train_data_g_sort_np_n[:, 0], c='b')
        plt.legend(["train_data_g_sort_np_n"], loc=2, ncol=2)  # 设置图例
        # plt.xlim(-6, 6)  # 设置X轴显示范围
        plt.ylim(-6, 6)  # 设置Y轴显示范围
        # plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
        # plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
        # plt.title('Samples in 2 dimension space')
        plt.xlabel('N', fontproperties='Arial', fontsize=14)
        plt.ylabel('train_data_g_sort_np_n', fontproperties='Arial', fontsize=14)
        # plt.show()
        plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/train_data_g_sort_np_n.png')

        # pin memory provides improved transfer speed
        # kwargs = {'num_workers': 1, 'pin_memory': True} if device == 'cuda' else {}
        # train_loader = torch.utils.data.DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True,**kwargs)  # 训练测试数据加载器，自动将数据分成batch
        # test_loader = torch.utils.data.DataLoader(test_data, batch_size=BATCH_SIZE, shuffle=True, **kwargs)
        #
        # train_loader2 = torch.utils.data.DataLoader(train_data2, batch_size=BATCH_SIZE, shuffle=True,**kwargs)  # 训练测试数据加载器，自动将数据分成batch
        # test_loader2 = torch.utils.data.DataLoader(test_data2, batch_size=BATCH_SIZE, shuffle=True, **kwargs)

    # ====================  1-2 data2-unlabel  不带标签  ===================
    for i in range(1):
        # --- data loading --- #
        # 导入样本X
        filename_MCS = LOG_DIR + '/Seq1/sampledata2.npz'
        dataMCS = np.load(filename_MCS)

        N2 = dataMCS['N']
        N = N2
        numvar = int(dataMCS['numvar'])
        XO = dataMCS['XO']
        X2 = dataMCS['X2']
        Y = dataMCS['Y']  # 在无标签样本中不起作用
        # Pf_MCS = dataMCS['Pf_MCS']   #用于计算条件概率密度
        Pf_MCS = 1.0  # 用于计算条件概率密度

        XDEN = dataMCS['XDEN']
        XDEN_Joint = np.ones((N, 1))  # 计算联合概率密度
        for i in range(0, numvar):
            XDEN_Joint[:, 0] = XDEN_Joint[:, 0] * XDEN[:, i]

        XDEN_Joint = XDEN_Joint / Pf_MCS  # 条件概率密度
        # XDEN_Joint=XDEN[:,0]*XDEN[:,1]

        dataset = np.zeros((N, numvar + 2))  # XO + Y + X2
        dataset[:, 0:numvar] = XO[:, 0:numvar]
        dataset[:, numvar] = Y[:, 0]
        dataset[:, numvar + 1] = X2[:, 0]
        dataset2 = dataset.astype(np.float64)
        dataset2[:, numvar] = 0  # 极限状态函数为空

        # 计算归一化参数初始值
        # m_init = np.mean(dataset2[:, numvar])  # 极限状态函数均值
        # std_init = np.std(dataset2[:, numvar])  # 极限状态函数标准差


    # ===============================  2 搭建生成网络   =============================

    # ===搭建G1模型-CouplingLayer网络（不限制单调递增）===
    class CouplingLayer(nn.Module):
        def __init__(self, input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, mask):
            super().__init__()

            # ======  s_fcs网络  （相乘的系数beta）
            self.num_layers_s = num_layers_s
            self.s_fc1 = nn.Sequential(nn.Linear(input_dim, hid_dim), nn.ReLU())
            dense_s = []
            for i in range(1, self.num_layers_s - 1):
                dense_s.append(nn.Sequential(nn.Linear(hid_dim, hid_dim), nn.ReLU()))
            self.dense_block_s = torch.nn.ModuleList(dense_s)
            # self.s_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim), nn.Tanh())  #Tanh激活，也可以线性激活
            self.s_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim))  # Tanh激活，也可以线性激活

            #  s_fcs网络参数初始化，bias小一点，避免突然映射得到偏离正太分布很远的分布
            MU_WEI_INIT_G1_s_fcs = 0
            STD_WEI_INIT_G1_s_fcs = 1e-3
            for name, param in self.s_fc1.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G1_s_fcs, STD_WEI_INIT_G1_s_fcs)
                    # print(1)
                if 'bias' in name:
                    # print(2)
                    nn.init.constant_(param, val=0.0)

            for name, param in self.dense_block_s.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G1_s_fcs, STD_WEI_INIT_G1_s_fcs)
                if 'bias' in name:
                    # print(1)
                    nn.init.constant_(param, val=0.0)
            for name, param in self.s_fc3.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G1_s_fcs, STD_WEI_INIT_G1_s_fcs)
                if 'bias' in name:
                    # print(1)
                    nn.init.constant_(param,
                                      val=0.8)  # G1  输出层初始值为1，映射系数为1，使得网络将高斯分布映射为原始高斯分布；该参数初始化为0容易导致log出现nan；任何数据分布都可以先预处理，rescale到N（0，1）附近。

            # ======  t_fcs网络  （相加的偏置项gama）
            self.num_layers_t = num_layers_t
            self.t_fc1 = nn.Sequential(nn.Linear(input_dim, hid_dim), nn.ReLU())
            dense_t = []
            for i in range(1, self.num_layers_t - 1):
                dense_t.append(nn.Sequential(nn.Linear(hid_dim, hid_dim), nn.ReLU()))
            self.dense_block_t = torch.nn.ModuleList(dense_t)
            self.t_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim))  # 线性激活
            # print( 'self.dense_block', self.dense_block  )

            #  t_fcs网络参数初始化
            MU_WEI_INIT_G1_t_fcs = 0
            STD_WEI_INIT_G1_t_fcs = 1e-3
            for name, param in self.t_fc1.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G1_t_fcs, STD_WEI_INIT_G1_t_fcs)
                if 'bias' in name:
                    # print(3)
                    nn.init.constant_(param, val=0.0)
            for name, param in self.dense_block_t.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G1_t_fcs, STD_WEI_INIT_G1_t_fcs)
                if 'bias' in name:
                    # print(1)
                    nn.init.constant_(param, val=0.0)

            for name, param in self.t_fc3.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G1_t_fcs, STD_WEI_INIT_G1_t_fcs)
                if 'bias' in name:
                    # print(1)
                    nn.init.constant_(param, val=0.0)  # 输出层初始值为0，映射加0，使得网络将高斯分布映射为原始高斯分布

            # ======  mask
            self.mask = mask  # mask  实现交替couplinglayer

        def forward(self, x):  # 求逆+计算雅可比矩阵行列式，由数据样本 到 高斯输入
            x_m = x * self.mask

            # ==s_fcs网络
            s_out = self.s_fc1(x_m)
            for module_s in self.dense_block_s:
                s_out = module_s(s_out)
            s_out = self.s_fc3(s_out)  # 相当于log(beta)，，torch.exp(s_out)相当于beta

            # ==t_fcs网络
            t_out = self.t_fc1(x_m)
            for module_t in self.dense_block_t:
                t_out = module_t(t_out)
            t_out = self.t_fc3(t_out)

            # y = x_m + (1 - self.mask) * (x * torch.exp(s_out) + t_out)  # x1-->xd 和 xd+1-->xD，s_out的激活函数相当于是exp(*),因此直接累加s_out.sum(dim=1)计算log_det_jacobian；但是exp限制了s_out网络只能输出正的，缩小了网络的表达能力；在G2网络中可以采用该激活函数。
            # log_det_jacobian = (s_out * (1 - self.mask)).sum(dim=1)  # s_out相对于exp(s_out)已经计算了log,,  是否应该只计算一半s_out的累加？
            y = x_m + (1 - self.mask) * (x * s_out + t_out)  # s_fcs网络（相乘的系数beta）改为线性激活，提高网络预测能力
            # log_det_jacobian =  (torch.log( torch.abs (s_out) + 1e-30 )* (1 - self.mask)).sum(dim=1)   #只计算一半s_out的累加,  对mini-batch累加，维数[1,numvar]
            log_det_jacobian = (torch.log(torch.abs(s_out)) * (1 - self.mask)).sum(
                dim=1)  # 只计算一半s_out的累加,  对mini-batch累加，维数[1,numvar]

            # y = torch.clamp(y, -1000, 1000)  #constraint the output
            return y, log_det_jacobian  # y取值范围负无穷到正无穷

        def backward(self, y):  # 采样，由高斯输入 到  数据样本
            y_m = y * self.mask

            # ==s_fcs网络
            s_out = self.s_fc1(y_m)
            for module in self.dense_block_s:
                s_out = module(s_out)
            s_out = self.s_fc3(s_out)  # 相当于log(beta)，，torch.exp(s_out)相当于beta

            # ==t_fcs网络
            t_out = self.t_fc1(y_m)
            for module_t in self.dense_block_t:
                t_out = module_t(t_out)
            t_out = self.t_fc3(t_out)

            # x = y_m + (1 - self.mask) * (y - t_out) * torch.exp(-s_out)  # x = y_m + (1 - self.mask) * (y - t_out) ./torch.exp(s_out)  #等效           #相除、分母要不等于0
            # x = y_m + (1 - self.mask) * (y - t_out) / (torch.log(torch.exp(s_out))+1e-20) #     #相除、分母要不等于0
            x = y_m + (1 - self.mask) * (y - t_out) / (s_out)  # #相除、分母要不等于0

            # print( x.shape) #[5,2]
            # x=torch.clamp(x,-1000,1000)   #constraint the output

            return x


    # ===搭建G2模型-CouplingLayer网络（不限制单调递增）===
    class CouplingLayer_G2(nn.Module):
        def __init__(self, input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, mask):
            super().__init__()

            # ======  s_fcs网络  （相乘的系数beta）
            self.num_layers_s = num_layers_s
            self.s_fc1 = nn.Sequential(nn.Linear(input_dim, hid_dim), nn.ReLU())
            dense_s = []
            for i in range(1, self.num_layers_s - 1):
                dense_s.append(nn.Sequential(nn.Linear(hid_dim, hid_dim), nn.ReLU()))
            self.dense_block_s = torch.nn.ModuleList(dense_s)
            # self.s_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim), nn.Tanh())  #Tanh激活，也可以线性激活
            self.s_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim))  # Tanh激活，也可以线性激活

            '''
            #  s_fcs网络参数初始化，bias小一点，避免突然映射得到偏离正太分布很远的分布
            MU_WEI_INIT_G2_s_fcs = 0
            STD_WEI_INIT_G2_s_fcs=1e-3
            for name, param in self.s_fc1.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G2_s_fcs, STD_WEI_INIT_G2_s_fcs)
                    # print(1)
                if 'bias' in name:
                    # print(2)
                    nn.init.constant_(param, val=0.0)

            for name, param in self.dense_block_s.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G2_s_fcs, STD_WEI_INIT_G2_s_fcs)
                if 'bias' in name:
                    # print(1)
                    nn.init.constant_(param, val=0.0)
            for name, param in self.s_fc3.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G2_s_fcs, STD_WEI_INIT_G2_s_fcs)
                if 'bias' in name:
                    # print(1)
                    nn.init.constant_(param, val=  1e2  )    # G2输出层初始值为0，计算exp激活函数后，映射系数为1，使得网络将高斯分布映射为原始高斯分布；(初始化是递增函数)

            '''

            # ======  t_fcs网络  （相加的偏置项gama）
            self.num_layers_t = num_layers_t
            self.t_fc1 = nn.Sequential(nn.Linear(input_dim, hid_dim), nn.ReLU())
            dense_t = []
            for i in range(1, self.num_layers_t - 1):
                dense_t.append(nn.Sequential(nn.Linear(hid_dim, hid_dim), nn.ReLU()))
            self.dense_block_t = torch.nn.ModuleList(dense_t)
            self.t_fc3 = nn.Sequential(nn.Linear(hid_dim, output_dim))  # 线性激活
            # print( 'self.dense_block', self.dense_block  )

            '''
            #  t_fcs网络参数初始化
            MU_WEI_INIT_G2_t_fcs = 0
            STD_WEI_INIT_G2_t_fcs=1e-3

            for name, param in self.t_fc1.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G2_t_fcs, STD_WEI_INIT_G2_t_fcs)
                if 'bias' in name:
                    # print(3)
                    nn.init.constant_(param, val=0.0)
            for name, param in self.dense_block_t.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G2_t_fcs, STD_WEI_INIT_G2_t_fcs)
                if 'bias' in name:
                    # print(1)
                    nn.init.constant_(param, val=0.0)

            for name, param in self.t_fc3.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, MU_WEI_INIT_G2_t_fcs, STD_WEI_INIT_G2_t_fcs)
                if 'bias' in name:
                    # print(1)
                    nn.init.constant_(param, val=0.0)
            '''

            # ======  mask
            self.mask = mask  # mask  实现交替couplinglayer

        def forward(self, x):  # 求逆+计算雅可比矩阵行列式，由数据样本 到 高斯输入
            x_m = x * self.mask

            # ==s_fcs网络
            s_out = self.s_fc1(x_m)
            for module_s in self.dense_block_s:
                s_out = module_s(s_out)
            s_out = self.s_fc3(s_out)  # 相当于log(beta)，，torch.exp(s_out)相当于beta

            # ==t_fcs网络
            t_out = self.t_fc1(x_m)
            for module_t in self.dense_block_t:
                t_out = module_t(t_out)
            t_out = self.t_fc3(t_out)

            y = x_m + (1 - self.mask) * (x * torch.exp(
                s_out) + t_out)  # x1-->xd 和 xd+1-->xD，s_out的激活函数相当于是exp(*),因此直接累加s_out.sum(dim=1)计算log_det_jacobian；但是exp限制了s_out网络只能输出正的，缩小了网络的表达能力；在G2网络中可以采用该激活函数。
            log_det_jacobian = (s_out * (1 - self.mask)).sum(dim=1)  # s_out相对于exp(s_out)已经计算了log,,  是否应该只计算一半s_out的累加？
            # y = x_m + (1 - self.mask) * (x * s_out + t_out)  # s_fcs网络（相乘的系数beta）改为线性激活，提高网络预测能力
            # log_det_jacobian =  (torch.log( torch.abs (s_out) + 1e-30 )* (1 - self.mask)).sum(dim=1)   #只计算一半s_out的累加,  对mini-batch累加，维数[1,numvar]

            return y, log_det_jacobian  # y取值范围负无穷到正无穷

        def backward(self, y):  # 采样，由高斯输入 到  数据样本
            y_m = y * self.mask

            # ==s_fcs网络
            s_out = self.s_fc1(y_m)
            for module in self.dense_block_s:
                s_out = module(s_out)
            s_out = self.s_fc3(s_out)  # 相当于log(beta)，，torch.exp(s_out)相当于beta

            # ==t_fcs网络
            t_out = self.t_fc1(y_m)
            for module_t in self.dense_block_t:
                t_out = module_t(t_out)
            t_out = self.t_fc3(t_out)

            x = y_m + (1 - self.mask) * (y - t_out) * torch.exp(-s_out)  # x = y_m + (1 - self.mask) * (y - t_out) ./torch.exp(s_out)  #等效           #相除、分母要不等于0
            # x = y_m + (1 - self.mask) * (y - t_out) / (s_out) #     #相除、分母要不等于0

            # print( x.shape) #[5,2]
            return x


    class SMNET(nn.Module):
        # 建立递增网络
        def __init__(self, input_size, group_num, group_size):
            super().__init__()
            self.layer_one = nn.Linear(input_size, group_num * group_size, bias=True)  # 将64个神经元，分为4组,每一组有16个神经元
            self.sigmoid = nn.Sigmoid()

            self.input_size = input_size
            self.group_num = group_num
            self.group_size = group_size
            self.groups = locals()
            self.group_maxs = locals()

            # self.betap = None  #define a list of indenpent betap
            self.betap = nn.Parameter(-1 * torch.ones(self.group_num), requires_grad=True)
            self.betan = nn.Parameter(torch.tensor(-1.0), requires_grad=True)

            for name, param in self.layer_one.named_parameters():
                # print(name,param)
                if 'weight' in name:
                    nn.init.normal_(param, 0.0, 1.0)
                    # print(1)
                if 'bias' in name:
                    # print(2)
                    # nn.init.constant_(param, val=0.0)
                    nn.init.normal_(param, 0.0, 1.0)

        def LSEN(self, xg):
            '''
            k=1时为正beta
            k=-1时为负beta
            '''

            # beta = k * torch.exp(nn.Parameter(torch.tensor(-1.0), requires_grad=True))
            # beta = nn.Parameter(    k * torch.exp(torch.tensor(-1.0))   ,    requires_grad=True)
            # beta = nn.Parameter(torch.tensor(-1.0), requires_grad=True)
            # beta=  torch.exp( nn.Parameter(torch.tensor( -1.0) , requires_grad=True)  )
            # beta=  nn.Parameter(torch.randn(1,2), requires_grad=True)
            # torch.log(beta)
            # print('betan', self.betan)
            c = 1e-8
            # c=torch.max(xg,dim=1).values
            # c=torch.reshape(torch.max(xg,dim=1).values, (-1, 1))
            # print(c.shape)
            # aa=torch.mul(xg, self.betap)
            # print(aa.shape)

            # torch.mul(a,beta)-c
            expout = torch.exp(torch.mul(xg, (-1.0 * torch.exp(self.betan))) - c)
            sumout = torch.sum(expout, dim=1)
            logout = torch.log(sumout)
            LSE = 1 / (-1.0 * torch.exp(self.betan)) * (c + logout)
            # print('self.betan', self.betan)

            return torch.reshape(LSE, (-1, 1))

        # forward这里就是神经网络的输入了
        def forward(self, input_x):
            length = len(input_x)
            input_x = self.layer_one(input_x)  # torch.Size([4, 64]);  torch.Size([batchsize, 64])

            # =====对层输出分组
            for i in range(0, self.group_num):
                self.groups['group%s' % i] = input_x[:, i * self.group_size: (
                                                                                         i + 1) * self.group_size]  # shape:[10,1,16],一共有16组神经元;  torch.Size([4, 16])

            # ======第1层计算--正beta----然后取每一个group当中，输出值最大的神经元
            # if self.betap is None:
            #     self.betap=nn.Parameter(-1*torch.ones(self.group_num), requires_grad=True)
            #     # print('self.betapsize',self.betap.shape)

            for i in range(0, self.group_num):
                #  i=0
                xg = self.groups['group%s' % i]
                # [r,l]=a.shape
                # x_LSEP = self.LSEP(xg)
                # ===LSEP

                betap = self.betap[i]
                c = 1e-8
                expout = torch.exp(torch.mul(xg, (1.0 * torch.exp(betap))) - c)
                sumout = torch.sum(expout, dim=1)
                logout = torch.log(sumout)
                LSE = 1 / (1.0 * torch.exp(betap)) * (c + logout)
                x_LSEP = torch.reshape(LSE, (-1, 1))

                self.group_maxs['group_max%s' % i] = x_LSEP

            # print('betap',  self.betap)

            # =======第2层计算--负beta----然后找到这4组数据的最小值.每一个数据，只选取4个数据当中的一个
            max_group = self.group_maxs['group_max%s' % 0]
            for i in range(1, self.group_num):
                max_group = torch.cat((max_group, self.group_maxs['group_max%s' % (i)]), dim=1)  # 横着拼
            y = self.LSEN(max_group)

            # print('self.betap',self.betap)
            # print('self.betan', self.betan)

            return y


    ##===权重裁剪函数======
    class WeightConstraint(object):
        # SMNET net
        def __init__(self):
            pass

        def __call__(self, module):
            if hasattr(module, 'weight') and hasattr(module, 'bias'):
                # print("Entered")
                w = module.weight.data
                # w = w.clamp(-1.0, 1.0)
                w = w.clamp(0.0, 1e30)
                b = module.bias.data
                b = b.clamp(-1000.0, 1000.0)

                # print(w)
                # w = torch.exp(w)

                module.weight.data = w
                module.bias.data = b

                # print(w)


    class WeightConstraintG1(object):
        def __init__(self):
            pass

        def __call__(self, module):
            if hasattr(module, 'weight') and hasattr(module, 'bias'):
                # print("Entered")
                w = module.weight.data
                # w = w.clamp(-1.0, 1.0)
                b = module.bias.data
                # b= b.clamp(-2.0, 2.0)

                # print(w)
                # w = torch.exp(w)

                module.weight.data = w
                module.bias.data = b

                # print(w)


    class WeightConstraintG2(object):
        def __init__(self):
            pass

        def __call__(self, module):
            if hasattr(module, 'weight') and hasattr(module, 'bias'):
                # print("Entered")
                w = module.weight.data

                # w = w.clamp(-1.0, 1.0)
                b = module.bias.data
                # b= b.clamp(-1.0, 1.0)
                #
                # print(w)
                # w = torch.exp(w)

                module.weight.data = w
                module.bias.data = b

                # print(w)


    class uncertainty_to_weigh_losses(nn.Module):
        def __init__(self, num_loss):
            super().__init__()
            self.num_loss = num_loss
            # self.weights = None  # define a list of indenpent betap
            self.weights = nn.Parameter(torch.ones(self.num_loss) / self.num_loss, requires_grad=True)

        # import torch.nn as nn
        def forward(self, loss_list):
            """
            所有任务的损失列表，为tensor格式
            :param loss_list:
            :return: tensor格式的综合损失
            """
            # if self.weights is None:
            #     self.weights=nn.Parameter(torch.ones(self.num_loss)/self.num_loss, requires_grad=True)
            #     # print('self.betapsize',self.betap.shape)

            final_loss = []
            for i in range(self.num_loss):
                final_loss.append(loss_list[i] / (2 * self.weights[i] ** 2) + torch.log(self.weights[i]))

            print('self.weights', self.weights)

            return sum(final_loss), final_loss, self.weights


    ##===搭建深度生成网络======
    class RealNVP(nn.Module):
        def __init__(self, input_dim, output_dim,
                     hid_dim, num_layers_s, num_layers_t, mask, n_layers,
                     hid_dim_G2, num_layers_s_G2, num_layers_t_G2, mask_G2, n_layers_G2,
                     input_size, group_num, group_size):
            super().__init__()

            # 实例化G1递增网络
            assert n_layers >= 2, 'num of coupling layers should be greater or equal to 2'
            self.modules = []
            self.modules.append(CouplingLayer(input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, mask))
            for _ in range(n_layers - 2):
                mask = 1 - mask  # 交替变换
                self.modules.append(CouplingLayer(input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, mask))
            self.modules.append(CouplingLayer(input_dim, output_dim, hid_dim, num_layers_s, num_layers_t, 1 - mask))
            self.module_list = nn.ModuleList(self.modules)

            # 实例化G2递增网络
            assert n_layers_G2 >= 2, 'num of coupling layers should be greater or equal to 2'
            self.modules_G2 = []
            self.modules_G2.append(CouplingLayer_G2(2, 2, hid_dim_G2, num_layers_s_G2, num_layers_t_G2, mask_G2))
            for _ in range(n_layers_G2 - 2):
                mask_G2 = 1 - mask_G2  # 交替变换
                self.modules_G2.append(CouplingLayer_G2(2, 2, hid_dim_G2, num_layers_s_G2, num_layers_t_G2, mask_G2))
            self.modules_G2.append(CouplingLayer_G2(2, 2, hid_dim_G2, num_layers_s_G2, num_layers_t_G2, 1 - mask_G2))
            self.module_list_G2 = nn.ModuleList(self.modules_G2)

            # 实例化SMNET递增网络,实例化全连接递增网络
            self.FDNN = SMNET(input_size, group_num, group_size)

            # 实例化SMNET
            self.UWLS4 = uncertainty_to_weigh_losses(3)  # 4个loss加权
            self.UWLS2 = uncertainty_to_weigh_losses(1)  # 2个loss加权
            self.UWLS1 = uncertainty_to_weigh_losses(1)  # 1个loss加权

        # ====调用G1网络===随机变量分布拟合
        def forward(self, x):  # 求逆+计算雅可比矩阵行列式
            ldj_sum = 0  # sum of log determinant of jacobian
            for module in self.module_list:
                x, ldj = module(x)  # 自动调用forward函数
                ldj_sum += ldj  # log_det_jacobian累加

            return x, ldj_sum

        def backward(self, z):  # 用于采样
            for module in reversed(self.module_list):
                z = module.backward(z)  # 手动调用backward函数
            return z

        # ====调用G2网络===样本响应预测
        def forward_G2(self, x):  # 求逆+计算雅可比矩阵行列式
            ldj_sum = 0  # sum of log determinant of jacobian
            for module in self.module_list_G2:
                x, ldj = module(x)  # 自动调用forward函数
                ldj_sum += ldj  # log_det_jacobian累加

            return x, ldj_sum

        def backward_G2(self, z):  # 用于采样
            for module in reversed(self.module_list_G2):
                z = module.backward(z)  # 手动调用backward函数
            return z

        # ====调用MNET网络===样本响应预测
        def fully_DNN(self, z0):
            # 定义全连接网络，根据z计算极限状态函数预测值
            g = self.FDNN(z0)
            # torch.cuda.empty_cache()
            return g

        # ====调用UWLS网络===
        def uwls4(self, loss):
            # 定义全连接网络，根据z计算极限状态函数预测值
            [sum_final_loss, final_loss, weights] = self.UWLS4(loss)
            return sum_final_loss, final_loss, weights

        def uwls2(self, loss):
            # 定义全连接网络，根据z计算极限状态函数预测值
            [sum_final_loss, final_loss, weights] = self.UWLS2(loss)
            return sum_final_loss, final_loss, weights

        def uwls1(self, loss):
            # 定义全连接网络，根据z计算极限状态函数预测值
            [sum_final_loss, final_loss, weights] = self.UWLS1(loss)
            return sum_final_loss, final_loss, weights


    ##===数据真实概率密度函数======
    # def data_distribution(numvar):
    #     # Loss3-1===计算真实概率密度logP==
    #     # 对数正态分布的均值和标准差
    #     mu1 = np.ones((numvar, 1), dtype=np.float64)
    #     sigma1 = np.ones((numvar, 1), dtype=np.float64) * 0.2
    #
    #     # 对数正态分布-所对应的正态分布的  均值和标准差
    #     X1_LOC = np.zeros((numvar, 1))  # 对数正态分布函数  的  输入参数
    #     X1_SIGMA = np.zeros((numvar, 1))  # 对数正态分布参数  的  输入参数
    #
    #     X1_LOC[0:numvar, 0] = np.log(np.power(mu1[0:numvar, 0], 2) / np.power((np.power(sigma1[0:numvar, 0], 2) + np.power(mu1[0:numvar, 0], 2)),  0.5))  # 正态分布对应的均值，即函数的参数
    #     X1_SIGMA[0:numvar, 0] = np.power(np.log(np.power(sigma1[0:numvar, 0], 2) / np.power(mu1[0:numvar, 0], 2) + 1), 0.5)  # 正态分布对应的标准差，即函数的参数
    #
    #     X1_LOC = np.squeeze(X1_LOC, axis=1)
    #     X1_SIGMA = np.squeeze(X1_SIGMA, axis=1)
    #
    #     loc = torch.from_numpy(X1_LOC).to(device)
    #     scale = torch.from_numpy(X1_SIGMA).to(device)
    #
    #     # 建立多个相对独立的对x数正态分布，计算logP
    #     px_real = distributions.LogNormal(loc,  scale)  # 定义目标真实概率密度函数，多维相互独立概率分布  (即使取失效区域的样本训练，条件概率密度大于完整分布的概率密度，也可以采用原始概率密度函数计算loss)
    #
    #     return px_real
    # p_data = data_distribution(numvar)


    #  1 对数分布
    def data_distribution_ln(numvar):
        # Loss3-1===计算真实概率密度logP==
        # 对数正态分布的均值和标准差
        mu1 = np.ones((numvar, 1), dtype=np.float32)
        sigma1 = np.ones((numvar, 1), dtype=np.float32) * 0.2

        # 对数正态分布-所对应的正态分布的  均值和标准差
        X1_LOC = np.zeros((numvar, 1))  # 对数正态分布函数  的  输入参数
        X1_SIGMA = np.zeros((numvar, 1))  # 对数正态分布参数  的  输入参数

        X1_LOC[0:numvar, 0] = np.log(
            np.power(mu1[0:numvar, 0], 2) / np.power((np.power(sigma1[0:numvar, 0], 2) + np.power(mu1[0:numvar, 0], 2)),
                                                     0.5))  # 正态分布对应的均值，即函数的参数
        X1_SIGMA[0:numvar, 0] = np.power(np.log(np.power(sigma1[0:numvar, 0], 2) / np.power(mu1[0:numvar, 0], 2) + 1),
                                         0.5)  # 正态分布对应的标准差，即函数的参数

        X1_LOC = np.squeeze(X1_LOC, axis=1)
        X1_SIGMA = np.squeeze(X1_SIGMA, axis=1)

        loc = torch.from_numpy(X1_LOC).to(device)
        scale = torch.from_numpy(X1_SIGMA).to(device)

        # 建立多个相对独立的对x数正态分布，计算logP
        px_real = distributions.LogNormal(loc,
                                          scale)  # 定义目标真实概率密度函数，多维相互独立概率分布  (即使取失效区域的样本训练，条件概率密度大于完整分布的概率密度，也可以采用原始概率密度函数计算loss)

        return px_real
    p_data_ln = data_distribution_ln(numvar - numduofeng)


    #  2 多峰分布
    class MixtureLogNormal:

        def __init__(self,
                     weights,
                     locs,
                     scales):

            self.weights = weights

            self.components = []

            for k in range(len(weights)):
                self.components.append(
                    distributions.LogNormal(
                        locs[:, k],
                        scales[:, k]
                    )
                )

        def log_prob(self, x):

            pdf = 0.0

            for w, comp in zip(
                    self.weights,
                    self.components):
                pdf += w * torch.exp(
                    comp.log_prob(x)
                )

            return torch.log(
                pdf + 1e-30
            )

        def sample(self, sample_shape=torch.Size()):

            raise NotImplementedError
    def data_distribution_df(numvar):

        # ==========================
        # 三个峰
        # ==========================

        # mu_mix = np.array( [0.5, 1.5, 3.0] )
        # sigma_mix = np.array(  [0.05, 0.10, 0.20] )
        # weight_mix = np.array( [0.3, 0.4, 0.3])

        mu_mix = np.array([1, 2])
        sigma_mix = np.array([0.2, 0.2])
        weight_mix = np.array([0.6, 0.4])

        K = len(mu_mix)

        locs = np.zeros(
            (numvar, K),
            dtype=np.float64
        )

        scales = np.zeros(
            (numvar, K),
            dtype=np.float64
        )

        # ==========================
        # 转换为LogNormal参数
        # ==========================

        for k in range(K):
            loc_k = np.log(
                mu_mix[k] ** 2 /
                np.sqrt(
                    mu_mix[k] ** 2 +
                    sigma_mix[k] ** 2
                )
            )

            scale_k = np.sqrt(
                np.log(
                    sigma_mix[k] ** 2 /
                    mu_mix[k] ** 2 + 1
                )
            )

            locs[:, k] = loc_k

            scales[:, k] = scale_k

        locs = torch.tensor(
            locs,
            dtype=torch.float64,
            device=device
        )

        scales = torch.tensor(
            scales,
            dtype=torch.float64,
            device=device
        )

        weights = torch.tensor(
            weight_mix,
            dtype=torch.float64,
            device=device
        )

        px_real = MixtureLogNormal(
            weights,
            locs,
            scales
        )

        return px_real
    p_data_df = data_distribution_df(numduofeng)

    ##===输入先验分布-高斯分布概率密度函数======

    meanz = torch.zeros(int(numvar)).to(device)
    eyez = torch.eye(int(numvar)).to(device)
    prior_z = distributions.MultivariateNormal(meanz, eyez)  # torch.eye(int(numvar)) 为协方差，而不是标准差


    # ===============================  3 训练生成网络   =============================

    def sample(z, model):
        model.eval()
        with torch.no_grad():
            # z = prior_z.sample((nsample,))   #生成随机高斯样本
            x = model.backward(z)  # 手动调用backward，采用backward采样

            z1, log_det_j_sum = model(x)  # 自动调用forward函数，求逆+计算雅可比矩阵行列式
            # print(z1.shape, log_det_j_sum.shape)  # [batcsize, n_dimsion],  [batcsize]

            # 采用真实高斯样本计算概率密度
            logprob = (prior_z.log_prob(z) + log_det_j_sum)  # prior_z需要与训练时的输入分布一致
            # print('logprob.shape',logprob.shape)

            px = torch.exp(logprob).cpu()
            px = np.reshape(px.numpy(), (-1, 1))

            z = z.cpu().numpy()
            x = x.cpu().numpy()

        return x, z1.cpu().numpy(), logprob.cpu().numpy(), px


    # =====实例化一个深度生成网络model======
    for i in range(1):
        # ==== 制作mask =====，实现coupling layer交替
        mask0 = np.zeros((1, numvar))
        maskn = int(numvar / 2)
        mask0[0, 0:maskn] = 1
        mask = torch.from_numpy(
            mask0.astype(np.float64))  # 将numpy数组转化为pytorch tensor，定义一个mask实现输入数据拆分交替变换 coupling layer
        mask = 1 - mask  # 交替变换
        mask = mask.to(device)

        mask0_G2 = np.zeros((1, 2))
        # maskn_G2 = int(numvar / 2)
        mask0_G2[0, 1] = 1
        mask_G2 = torch.from_numpy(
            mask0_G2.astype(np.float64))  # 将numpy数组转化为pytorch tensor，定义一个mask实现输入数据拆分交替变换 coupling layer
        mask_G2 = 1 - mask_G2  # 交替变换
        mask_G2 = mask_G2.to(device)

        constraints = WeightConstraint()  # 权重裁剪，保持为正
        constraintsG1 = WeightConstraintG1()  # 权重裁剪，
        constraintsG2 = WeightConstraintG2()  # 权重裁剪，

        # UWLS4=uncertainty_to_weigh_losses(4)

        model_initial = RealNVP(INPUT_DIM, OUTPUT_DIM,
                                HIDDEN_DIM, NUM_LAYERS_S, NUM_LAYERS_T, mask, N_COUPLE_LAYERS,
                                HIDDEN_DIM_G2, NUM_LAYERS_S_G2, NUM_LAYERS_T_G2, mask_G2, N_COUPLE_LAYERS_G2,
                                INPUT_SIZE, GROUP_NUM, GROUP_SIZE)
        # print(model_initial)
        # print(model_initial.FDNN)
        # print(model.module_list)
        model_initial = model_initial.to(device)

        # print(list(model_initial.parameters()))
        # print(list(uncertainty_to_weigh_losses4.parameters()))
        # print(list(model_initial.UWLS4.parameters()))  #output []
        # print(list(model_initial.UWLS4.parameters()))  #output []

    ##==== 3-4    导入model参数=====
    state_dict = torch.load(LOG_DIR + '/Seq' + str(sequence - 2) + '/InfoDGN_model_TrainModel' + str(model_epoch) + '.pth')
    model = model_initial
    model.load_state_dict(state_dict['model'])




#===================3 预测响应g(x)的概率密度 PDF+CDF ===================================================

#===========3.1  PDF  ========
#==== 生成g(x)样本
kstd=5
Num_gx=10000
g_low=m_init-kstd*std_init   #上下界
g_up=m_init+kstd*std_init
gx=np.reshape( np.linspace(g_low,g_up,Num_gx ),(-1,1))   #原始响应样本
gx_n=(gx-m_init)/std_init    #对应归一化的响应样本
'''
#直方图检查数据
plt.figure(figsize=[6,6])
plt.hist(gx_n[:,0], 100, density=True)   #直方图
plt.xlabel(u'd)',fontproperties='Arial', fontsize=14)
plt.ylabel(u'Probability density',fontproperties='Arial', fontsize=14)
plt.show()
'''

#==== 定义构造的概率分布f(b)，b为G2网络的输出
prior_b = distributions.Normal(0, 1)  # 一维正态分布
log_f_b=prior_b.log_prob(torch.zeros(1))
f_b=torch.exp(log_f_b)
f_b=f_b.numpy()
b=torch.zeros(( Num_gx ,1))  #b的样本，全部取0.
'''
#测试正态分布概率密度
from scipy.stats import  norm
mu=0
std=1
xx=0
pdfx=norm.pdf(xx,mu,std)
'''
#==== 定义输入分布f(z1,a)-高斯分布概率密度函数======
prior_z1a = distributions.MultivariateNormal(torch.zeros(2).to(device),torch.eye(2).to(device))  # torch.eye(int(numvar)) 为协方差，而不是标准差。G2网络的输入z1+a
#===== 计算f(gx_n,b)
gxn_b = torch.hstack((torch.from_numpy( gx_n ), b)).to(device)  # 合并G2网络输出真实值  ， g(x)+b,也就是g(x)+a
z1_a, log_det_j_sum = model.forward_G2(gxn_b )  # 自动调用forward函数，求逆+计算雅可比矩阵行列式,#G2网络输入  z1+a
logprob_gxn_b = (prior_z1a.log_prob(z1_a) + log_det_j_sum)  # 采用真实高斯样本计算概率密度 # prior_z需要与训练时的输入分布一致，
# print('logprob.shape',logprob.shape)
p_gxn_b0 = torch.exp(logprob_gxn_b)
p_gxn_b = np.reshape( p_gxn_b0.cpu().detach().numpy(), (-1,1))
#===== 计算f(gx)  的pdf  =====
p_gxn = p_gxn_b/f_b   #归一化的响应概率密度
p_gx =p_gxn/std_init  #未归一化的原始随机变量
# p_gx =p_gxn

#绘图---响应pdf
plt.clf()
plt.close('all')
fig=plt.figure()
mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
plt.title('PDF')
plt.plot(gx, p_gx,c='g')
# plt.hist(Y[:,0], 100, density=True)   #直方图
plt.legend(["PDF---f(g(x))"], loc=2, ncol=2)   #设置图例
plt.xlim(g_low, g_up)  # 设置X轴显示范围
# plt.ylim(-6, 6)  # 设置Y轴显示范围
# plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
# plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
# plt.title('Samples in 2 dimension space')
plt.xlabel('step', fontproperties='Arial', fontsize=14)
plt.ylabel('loss', fontproperties='Arial', fontsize=14)
# plt.show()
plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/响应概率密度PDF---f(g(x)).png')




#===========3.2  CDF  ====================================

#==== 定义z1的概率分布f(z1)
prior_z1 = distributions.Normal(0, 1)  # 一维正态分布

#==== 计算cdf
z1=  torch.reshape( z1_a[:,0] ,(-1,1)      ).to(device)  #G2网络输入  z1+a,第0列是z1
F_gxn = prior_z1.cdf(z1)  # 条件概率
F_gx =F_gxn.cpu().detach().numpy()   #未归一化的响应gx累积概率分布cdf等于对应归一化的gxn的cdf

#绘图---响应cdf
plt.clf()
plt.close('all')
fig=plt.figure()
mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
plt.title('CDF')
plt.plot(gx, F_gx,c='g')
plt.legend(["CDF---F(g(x))"], loc=2, ncol=2)   #设置图例
plt.xlim(g_low, g_up)  # 设置X轴显示范围
# plt.ylim(-6, 6)  # 设置Y轴显示范围
# plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
# plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
# plt.title('Samples in 2 dimension space')
plt.xlabel('step', fontproperties='Arial', fontsize=14)
plt.ylabel('loss', fontproperties='Arial', fontsize=14)
# plt.show()
plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/响应累积概率分布CDF---F(g(x)).png')





#===========3.3  PDF(预测+MCS真实)  ========

#MCS
import C0_MCS
[pf_mcs,y_mcs] = C0_MCS.MCS(0, result, numvar,100000,False)

#响应预测pdf
import pandas as pd
plt.clf()
plt.close('all')
fig=plt.figure()
mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
plt.title('PDF')
plt.plot(gx, p_gx,c='r')

#响应真实pdf
plt.hist(y_mcs[:,0], 100, density=True)   #直方图
data = pd.Series(y_mcs[:,0])
data.plot(kind = 'kde', label = 'PDF_REAL',c='y')  #MCS概率密度

#格式控制
plt.legend(["f(g(x))_Predict",  "f(g(x))_REAL",  ], loc=2, ncol=2)   #设置图例
plt.xlim(g_low, g_up)  # 设置X轴显示范围
# plt.ylim(-6, 6)  # 设置Y轴显示范围
# plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
# plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
# plt.title('Samples in 2 dimension space')
plt.xlabel('step', fontproperties='Arial', fontsize=14)
plt.ylabel('loss', fontproperties='Arial', fontsize=14)
# plt.show()
plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/响应概率密度PDF---f(g(x))-real+pred.png')





#===========3.4  CDF(预测+MCS真实)  ====================================

#==== 定义z1的概率分布f(z1)
prior_z1 = distributions.Normal(0, 1)  # 一维正态分布

#==== 计算响应预测cdf
z1=  torch.reshape( z1_a[:,0] ,(-1,1)      )  #G2网络输入  z1+a,第0列是z1
F_gxn = prior_z1.cdf(z1)  # 条件概率
F_gx =F_gxn.cpu().detach().numpy()   #未归一化的响应gx累积概率分布cdf等于对应归一化的gxn的cdf
#绘图
plt.clf()
plt.close('all')
fig=plt.figure()
mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
plt.title('CDF')
plt.plot(gx, F_gx,c='r')

#响应gx真实CDF
sorted_data = np.sort(y_mcs[:,0]) # 先对数据进行排序
yvals = np.arange(len(sorted_data)) / float(len(sorted_data)-1) # 计算对应的CDF值
plt.plot(sorted_data, yvals,c='y') # 绘制CDF曲线
#格式控制
plt.legend(["F(g(x))predict","F(g(x))real"], loc=2, ncol=2)   #设置图例
plt.xlim(g_low, g_up)  # 设置X轴显示范围
# plt.ylim(-6, 6)  # 设置Y轴显示范围
# plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
# plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
# plt.title('Samples in 2 dimension space')
plt.xlabel('step', fontproperties='Arial', fontsize=14)
plt.ylabel('loss', fontproperties='Arial', fontsize=14)
# plt.show()
plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/响应累积概率分布CDF---F(g(x))-real+pred.png')





#===========3.5  对比G2网络输入输出的关系 a与b (参考C2_InfoDGN_testG2_20231126代码)  ========

#G2网络输入z1+a
z1_a_np=z1_a.cpu().detach().numpy()
#G2网络输出gxn+b
gxn_b_np=gxn_b.cpu().numpy()

# ====绘图====
plt.clf()
plt.close('all')
fig = plt.figure()
mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
plt.title('loss_functions')
plt.plot(z1_a_np[:, 0], gxn_b_np[:, 0], c='k')    #z1+gxn
plt.plot(z1_a_np[:, 0], z1_a_np[:, 1], c='r')    #z1+a
plt.plot(z1_a_np[:, 0], gxn_b_np[:, 1], c='b')    #z1+b
plt.legend(["gxn", "a", "b"], loc=2, ncol=2)  # 设置图例
# plt.xlim(-6, 6)  # 设置X轴显示范围
# plt.ylim(-0.5, 0.5)  # 设置Y轴显示范围
# plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
# plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
# plt.title('Samples in 2 dimension space')
plt.xlabel('X1', fontproperties='Arial', fontsize=14)
plt.ylabel('Values', fontproperties='Arial', fontsize=14)
# plt.show()
plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/z1_to_a+gxn+b.png')


plt.clf()
plt.close('all')
fig = plt.figure()
mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
plt.title('loss_functions')
# plt.plot(z1_a_np[:, 0], gxn_b_np[:, 0], c='k')    #z1+gxn
plt.plot(z1_a_np[:, 0], z1_a_np[:, 1], c='r')    #z1+a
plt.plot(z1_a_np[:, 0], gxn_b_np[:, 1], c='b')    #z1+b
plt.legend(["a", "b"], loc=2, ncol=2)  # 设置图例
# plt.xlim(-6, 6)  # 设置X轴显示范围
# plt.ylim(-0.5, 0.5)  # 设置Y轴显示范围
# plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
# plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
# plt.title('Samples in 2 dimension space')
plt.xlabel('X1', fontproperties='Arial', fontsize=14)
plt.ylabel('Values', fontproperties='Arial', fontsize=14)
# plt.show()
plt.savefig(LOG_DIR + '/Seq' + str(sequence) + '/z1_to_a+b.png')






#==================================3.6-3.7 对比PDF+CDF+Hellinger 距离 (2026.04.30) =========================

#===========3.6 PDF(预测+MCS真实)   同时采用MCS样本计算预测PDF (2026.04.30)  ========
#3.6.1 MCS
Num_S=40000
import C0_MCS
[pf_mcs,y_mcs] = C0_MCS.MCS(0, result, numvar,Num_S,False)

y_mcs = np.sort(y_mcs, axis=0)

#3.6.2  predict PDF
gx=y_mcs  #原始响应样本
gx_n=(gx-m_init)/std_init    #对应归一化的响应样本


'''
#直方图检查数据
plt.figure(figsize=[6,6])
plt.hist(gx_n[:,0], 100, density=True)   #直方图
plt.xlabel(u'd)',fontproperties='Arial', fontsize=14)
plt.ylabel(u'Probability density',fontproperties='Arial', fontsize=14)
plt.show()
'''

#==== 定义构造的概率分布f(b)，b为G2网络的输出
prior_b = distributions.Normal(0, 1)  # 一维正态分布
log_f_b=prior_b.log_prob(torch.zeros(1))
f_b=torch.exp(log_f_b)
f_b=f_b.numpy()
b=torch.zeros(( Num_S ,1))  #b的样本，全部取0.
'''
#测试正态分布概率密度
from scipy.stats import  norm
mu=0
std=1
xx=0
pdfx=norm.pdf(xx,mu,std)
'''
#==== 定义输入分布f(z1,a)-高斯分布概率密度函数======
prior_z1a = distributions.MultivariateNormal(torch.zeros(2).to(device),torch.eye(2).to(device))  # torch.eye(int(numvar)) 为协方差，而不是标准差。G2网络的输入z1+a
#===== 计算f(gx_n,b)
gxn_b = torch.hstack((torch.from_numpy( gx_n ), b)).to(device)  # 合并G2网络输出真实值  ， g(x)+b,也就是g(x)+a
z1_a, log_det_j_sum = model.forward_G2(gxn_b )  # 自动调用forward函数，求逆+计算雅可比矩阵行列式,#G2网络输入  z1+a
logprob_gxn_b = (prior_z1a.log_prob(z1_a) + log_det_j_sum)  # 采用真实高斯样本计算概率密度 # prior_z需要与训练时的输入分布一致，
# print('logprob.shape',logprob.shape)
p_gxn_b0 = torch.exp(logprob_gxn_b)
p_gxn_b = np.reshape( p_gxn_b0.cpu().detach().numpy(), (-1,1))
#===== 计算f(gx)  的pdf  =====
p_gxn = p_gxn_b/f_b   #归一化的响应概率密度
p_gx =p_gxn/std_init  #未归一化的原始随机变量
# p_gx =p_gxn


#3.6.3  plot predict PDF  and actual PDF
#响应预测pdf
import pandas as pd
plt.clf()
plt.close('all')
fig=plt.figure()
mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
plt.title('PDF')
plt.plot(gx, p_gx,c='r')

#响应真实pdf
plt.hist(y_mcs[:,0], 100, density=True)   #直方图
data = pd.Series(y_mcs[:,0])
data.plot(kind = 'kde', label = 'PDF_REAL',c='y')  #MCS概率密度

#格式控制
plt.legend(["f(g(x))_Predict",  "f(g(x))_REAL",  ], loc=2, ncol=2)   #设置图例
plt.xlim(g_low, g_up)  # 设置X轴显示范围
# plt.ylim(-6, 6)  # 设置Y轴显示范围
# plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
# plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
# plt.title('Samples in 2 dimension space')
plt.xlabel('step', fontproperties='Arial', fontsize=14)
plt.ylabel('loss', fontproperties='Arial', fontsize=14)
# plt.show()
plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/响应概率密度PDF---f(g(x))-real+pred-V2.png')


#===========3.7  CDF(预测+MCS真实) 同时采用MCS样本计算预测CDF (2026.04.30)  ====================================

#==== 定义z1的概率分布f(z1)
prior_z1 = distributions.Normal(0, 1)  # 一维正态分布

#==== 计算响应预测cdf
z1=  torch.reshape( z1_a[:,0] ,(-1,1)      )  #G2网络输入  z1+a,第0列是z1
F_gxn = prior_z1.cdf(z1)  # 条件概率
F_gx =F_gxn.cpu().detach().numpy()   #未归一化的响应gx累积概率分布cdf等于对应归一化的gxn的cdf
#绘图
plt.clf()
plt.close('all')
fig=plt.figure()
mpl.rcParams['font.size'] = 14  # 需要在fig前面定义
mpl.rcParams['font.sans-serif'] = 'Arial'  # 需要在fig前面定义
plt.title('CDF')
plt.plot(gx, F_gx,c='r')

#响应gx真实CDF
sorted_data = np.sort(y_mcs[:,0]) # 先对数据进行排序
yvals = np.arange(len(sorted_data)) / float(len(sorted_data)-1) # 计算对应的CDF值
plt.plot(sorted_data, yvals,c='y') # 绘制CDF曲线
#格式控制
plt.legend(["F(g(x))predict","F(g(x))real"], loc=2, ncol=2)   #设置图例
plt.xlim(g_low, g_up)  # 设置X轴显示范围
# plt.ylim(-6, 6)  # 设置Y轴显示范围
# plt.xticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置X轴刻度,范围和个数
# plt.yticks(np.linspace(-10,10,5),fontproperties='Arial', fontsize=14)   #设置Y轴刻度,范围和个数
# plt.title('Samples in 2 dimension space')
plt.xlabel('step', fontproperties='Arial', fontsize=14)
plt.ylabel('loss', fontproperties='Arial', fontsize=14)
# plt.show()
plt.savefig(LOG_DIR + '/Seq' + str(sequence) +'/响应累积概率分布CDF---F(g(x))-real+pred-V2.png')



#===========3.7 Hellinger 距离 同时采用MCS样本计算预测PDF (2026.04.30)  ========
y_mcs = np.reshape(y_mcs, (-1,))
p_gx = np.reshape(p_gx, (-1,))

import numpy as np
from scipy.stats import gaussian_kde

def hellinger_distance_from_samples(y_mcs, p_gx):
    """
    y_mcs : (N,) 真实样本
    p_gx  : (N,) A模型在y_mcs上的pdf预测值
    """

    # =========================
    # 1. KDE估计真实pdf
    # =========================
    kde = gaussian_kde(y_mcs)
    p_true = kde(y_mcs)

    # =========================
    # 2. 转为numpy数组
    # =========================
    p_true = np.asarray(p_true)
    p_pred = np.asarray(p_gx)

    # =========================
    # 3. 归一化（离散概率）
    # =========================
    p_true = p_true / np.sum(p_true)
    p_pred = p_pred / np.sum(p_pred)

    # 防止数值问题
    eps = 1e-12
    p_true = np.clip(p_true, eps, None)
    p_pred = np.clip(p_pred, eps, None)

    # =========================
    # 4. Hellinger距离
    # =========================
    H = (1 / np.sqrt(2)) * np.sqrt(np.sum((np.sqrt(p_true) - np.sqrt(p_pred))**2))

    return H



# 示例数据
# y_mcs = np.random.randn(2000)
# p_gx = 1/np.sqrt(2*np.pi) * np.exp(-0.5*y_mcs**2)  # 假设模型

H = hellinger_distance_from_samples(y_mcs, p_gx)
print("Hellinger distance:", H)



##=====================  5 保存重要抽样结果 ==========================================

for i in range(1):
    # NUMPY格式
    filename = LOG_DIR + '/Seq'+str(sequence)+ '/PDF_Prediction.npz'
    np.savez(filename,  m_init=m_init, \
                        std_init=std_init, \
                        gx=gx,\
                        gx_n=gx_n,\
                        gxn_b=gxn_b.cpu().detach().numpy(), \
                        z1_a=z1_a.cpu().detach().numpy(),\
                        p_gxn=p_gxn, \
                        p_gx=p_gx,\
                        F_gx=F_gx, \
                        H=H, \
                        yvals=yvals,\
                       )

    # mat格式
    io.savemat(LOG_DIR + '/Seq'+str(sequence)+ '/PDF_Prediction.mat',\
                       {'m_init':m_init,\
                        'std_init': std_init, \
                        'gx': gx, \
                        'gx_n':gx_n,\
                        'gxn_b': gxn_b.cpu().detach().numpy(), \
                        'z1_a': z1_a.cpu().detach().numpy(), \
                        'p_gxn': p_gxn, \
                        'p_gx': p_gx, \
                        'F_gx': F_gx, \
                        'H': H, \
                        'yvals':yvals,\
                        })  # 只保存numpy数组格式的。列表保存后，matlab无法导入



print("PDF_Prediction has been completed ! ")

# return pf_is

