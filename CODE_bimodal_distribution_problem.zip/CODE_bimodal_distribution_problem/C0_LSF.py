


def Z(x):  # 定义功能函数,输入X为向量（numvar,）

    import numpy as np

    # 函数
    n=x.shape[1]
    sigmax=0.2
    Z = (n+3*sigmax*n**0.5 )- np. sum(x,axis= 1)

    Z=Z.reshape(-1, )

    return Z


#
def fun_z(x):  # 定义功能函数,输入X为向量（numvar,）
    #
    # print('x',x[:,0])
    # print('x', x[:, 1])
    import numpy as np

    z0= x[:,0]-1e-10

    z = z0.reshape(-1, )*1.0
    # print('z',z)
    return z

